USE DealershipApp
GO

ALTER PROC [dbo].[spt_StandardBookingTimes_Insert]

	@Deleted bit = 0,
	@Active bit = 1,
	@Name varchar(255),
	@TimeInMinutes int,
	@DealershipId int  = NULL

 AS
 BEGIN
	INSERT INTO StandardBookingTimes
	(
		Deleted,
		Active,
		Name,
		TimeInMinutes,
		DealershipId

	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@TimeInMinutes,
		@DealershipId
	)
END
