USE [DealershipApp]
GO

/****** Object:  Table [dbo].[StandardBookingTimes]    Script Date: 2021/11/19 8:13:31 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[StandardBookingTimes](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](255) NOT NULL,
	[TimeInMinutes] [int] NOT NULL,
	[DealershipId] [int] NULL,
	[ipkStandardBookingTimeId] [int] NULL,
 CONSTRAINT [PK_StandardBookingTimes] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[StandardBookingTimes] ADD  CONSTRAINT [DF_StandardBookingTimes_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[StandardBookingTimes] ADD  CONSTRAINT [DF_StandardBookingTimes_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[StandardBookingTimes] ADD  CONSTRAINT [DF_StandardBookingTimes_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[StandardBookingTimes]  WITH CHECK ADD  CONSTRAINT [FK_StandardBookingTimes_DealershipId] FOREIGN KEY([DealershipId])
REFERENCES [dbo].[Dealerships] ([Id])
GO

ALTER TABLE [dbo].[StandardBookingTimes] CHECK CONSTRAINT [FK_StandardBookingTimes_DealershipId]
GO
