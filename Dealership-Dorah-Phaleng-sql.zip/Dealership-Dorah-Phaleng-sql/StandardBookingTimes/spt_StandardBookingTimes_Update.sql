USE DealershipApp
GO

ALTER PROC [dbo].[spt_StandardBookingTimes _Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(255) = NULL,
		@TimeInMinutes int = NULL,
		@DealershipId int  = NULL
 AS
 BEGIN
	UPDATE StandardBookingTimes
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name,Name),
		TimeInMinutes = ISNULL(@TimeInMinutes,TimeInMinutes),
		DealershipId = ISNULL(@DealershipId,DealershipId)

	WHERE
		Id = @Id
END
