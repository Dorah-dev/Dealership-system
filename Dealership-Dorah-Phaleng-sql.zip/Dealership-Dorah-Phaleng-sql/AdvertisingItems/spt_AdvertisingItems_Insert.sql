USE DealershipApp
GO

CREATE PROC [dbo].[spt_AdvertisingItems_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(32),
		@Description varchar(512) = NULL,
    @UserId int = NULL,
    @DateStart datetime = NULL,
    @DateEnd datetime = NULL,
    @AdvertisingCategoryId int = NULL,
    @DepartmentTypeId int = NULL,
		@DealershipId int = NULL
 AS
 BEGIN
	INSERT INTO AdvertisingItems
	(
		Deleted,
		Active,
		Name,
		Description,
    UserId,
    DateStart,
    DateEnd,
    AdvertisingCategoryId,
    DepartmentTypeId,
		DealershipId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@Description,
		@UserId,
		@DateStart,
		@DateEnd,
		@AdvertisingCategoryId,
		@DepartmentTypeId,
		@DealershipId
	)
END
