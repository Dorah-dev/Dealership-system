USE DealershipApp
GO


CREATE PROC [dbo].[spt_AdvertisingItems_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(32) = NULL,
		@Description varchar(512) = NULL,
    @UserId int = NULL,
    @IsVisible bit = NULL,
    @IsCallACar bit = NULL,
    @IsDisplayExternalLead bit = NULL,
    @DateStart datetime = NULL,
    @DateEnd datetime = NULL,
    @AdvertisingCategoryId int = NULL,
    @DepartmentTypeId int = NULL,
		@DealershipId int = NULL
 AS
 BEGIN
	UPDATE AdvertisingItems
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name,Name),
		Description = ISNULL(@Description,Description),
		DateStart = ISNULL(@DateStart,DateStart),
		DateEnd = ISNULL(@DateEnd,DateEnd),
		IsVisible = ISNULL(@IsVisible,IsVisible),
		IsCallACar = ISNULL(@IsCallACar,IsCallACar),
		IsDisplayExternalLead = ISNULL(@IsDisplayExternalLead,IsDisplayExternalLead),
		AdvertisingCategoryId = ISNULL(@AdvertisingCategoryId,AdvertisingCategoryId),
		DepartmentTypeId = ISNULL(@DepartmentTypeId,DepartmentTypeId),
		DealershipId = ISNULL(@DealershipId,DealershipId)
	WHERE
		Id = @Id
END
