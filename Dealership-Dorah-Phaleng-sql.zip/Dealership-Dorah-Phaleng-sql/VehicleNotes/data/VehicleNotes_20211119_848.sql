UPDATE [dbo].[VehicleNotes]
SET [UserId] = (SELECT TOP (1) Staff.UserId FROM Staff WHERE Staff.Id = [StaffId])
WHERE [UserId] IS NULL;
