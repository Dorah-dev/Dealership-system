USE DealershipApp
GO

ALTER PROC [dbo].[spt_VehicleNotes_Insert]
		 @Deleted bit = 0,
		 @Active bit = 1,
		 @NoteId int,
		 @VehicleId int,
		 @CustomerId int = NULL,
		 @ApplicationId int = NULL,
		 @DealershipId int = NULL,
		 @UserId int
 AS
 BEGIN
	INSERT INTO VehicleNotes
	(
		Deleted,
		Active,
		NoteId,
		VehicleId,
		CustomerId,
		ApplicationId,
		DealershipId,
		UserId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@NoteId,
		@VehicleId,
		@CustomerId,
		@ApplicationId,
		@DealershipId,
		@UserId
	)
END
