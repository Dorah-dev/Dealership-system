ALTER TABLE [dbo].[VehicleNotes]
ADD UserId [int] NULL
GO
ALTER TABLE [dbo].[VehicleNotes]  WITH CHECK ADD  CONSTRAINT [FK_VehicleNotes_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO
