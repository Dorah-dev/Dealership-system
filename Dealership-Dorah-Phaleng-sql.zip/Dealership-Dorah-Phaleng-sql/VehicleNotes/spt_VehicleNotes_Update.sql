USE DealershipApp
GO

ALTER PROC [dbo].[spt_VehicleNotes_Update]
	 @Id int,
	 @Deleted bit = NULL,
	 @Active bit = NULL,
	 @NoteId int = NULL,
	 @VehicleId int = NULL,
 	 @CustomerId int = NULL,
 	 @ApplicationId int = NULL,
 	 @DealershipId int = NULL,
	 @UserId int = NULL
 AS
 BEGIN
	UPDATE VehicleNotes
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		NoteId = ISNULL(@NoteId, NoteId),
		VehicleId = ISNULL(@VehicleId, VehicleId),
		CustomerId = ISNULL(@CustomerId, CustomerId),
		ApplicationId = ISNULL(@ApplicationId, ApplicationId),
		DealershipId = ISNULL(@DealershipId, DealershipId),
		UserId = ISNULL(@UserId, UserId)
	WHERE
		Id = @Id
END
