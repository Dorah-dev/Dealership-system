ALTER TABLE [dbo].[VehicleReminders]
ADD UserId [int] NULL
GO
ALTER TABLE [dbo].[VehicleReminders]  WITH CHECK ADD  CONSTRAINT [FK_VehicleReminders_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO
