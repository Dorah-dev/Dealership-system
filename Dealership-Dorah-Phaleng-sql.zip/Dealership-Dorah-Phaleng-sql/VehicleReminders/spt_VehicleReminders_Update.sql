USE DealershipApp
GO

ALTER PROC [dbo].[spt_VehicleReminders_Update]
	 @Id int,
	 @Deleted bit = NULL,
	 @Active bit = NULL,
	 @ReminderId int = NULL,
	 @VehicleId int = NULL,
 	 @ApplicationId int = NULL,
 	 @DealershipId int = NULL,
	 @UserId int = NULL

 AS
 BEGIN
	UPDATE VehicleReminders
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		ReminderId = ISNULL(@ReminderId, ReminderId),
		VehicleId = ISNULL(@VehicleId, VehicleId),
		ApplicationId = ISNULL(@ApplicationId, ApplicationId),
		DealershipId = ISNULL(@DealershipId, DealershipId),
		UserId = ISNULL(@UserId, UserId)

	WHERE
		Id = @Id
END
