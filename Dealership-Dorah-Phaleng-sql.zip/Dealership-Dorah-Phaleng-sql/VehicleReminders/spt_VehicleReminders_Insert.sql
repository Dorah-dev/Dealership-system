USE DealershipApp
GO

ALTER PROC [dbo].[spt_VehicleReminders_Insert]
		 @Deleted bit = 0,
		 @Active bit = 1,
		 @ReminderId int,
		 @VehicleId int,
		 @ApplicationId int = NULL,
		 @DealershipId int = NULL,
		 @UserId int
 AS
 BEGIN
	INSERT INTO VehicleReminders
	(
		Deleted,
		Active,
		ReminderId,
		VehicleId,
		ApplicationId,
		DealershipId,
		UserId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@ReminderId,
		@VehicleId,
		@ApplicationId,
		@DealershipId,
		@UserId
	)
END
