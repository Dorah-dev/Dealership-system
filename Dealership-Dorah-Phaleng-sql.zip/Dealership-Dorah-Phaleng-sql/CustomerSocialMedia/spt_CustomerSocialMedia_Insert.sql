USE [DealershipApp]
GO

ALTER PROC [dbo].[spt_CustomerSocialMedia_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@SocialMediaTypeId int = NULL,
		@CustomerId int = NULL,
		@IsPrimary bit = 1,
        @URL varchar(512) = NULL,
		@ipkSocialPrefID int = NULL,
		@ifkSocialPrefTypeID int = NULL,
		@ifkCustomerID int = NULL

 AS
 BEGIN
	INSERT INTO CustomerSocialMedia
	(
		Deleted,
		Active,
		SocialMediaTypeId,
		CustomerId,
		IsPrimary,
		URL
	) OUTPUT INSERTED.Id 
	VALUES
	(
		@Deleted,
		@Active,
		@SocialMediaTypeId,
		@CustomerId,
		@IsPrimary,
		@URL
	)
END
