USE DealershipApp
GO

ALTER PROC [dbo].[spt_CreditProviders_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(150) = NULL,
		@IdentificationNumber varchar(50) = NULL,
		@EmailAddress varchar(80) = NULL,
		@PhoneNumber varchar(25) = NULL,
		@FaxNumber varchar(20) = NULL,
		@TypeOtherOfOrganisation varchar(50) = NULL,
		@PostalAddress varchar(100) = NULL,
		@PostalSuburb varchar(40) = NULL,
		@PostalCity varchar(40) = NULL,
		@PostalPostalCode varchar(6) = NULL,
		@StreetAddress varchar(100) = NULL,
		@StreetSuburb varchar(40) = NULL,
		@StreetCity varchar(40) = NULL,
		@StreetPostalCode varchar(6) = NULL,
		@NotificationAddress int = NULL,
		@CountryId int = NULL,
		@DealershipId int = NULL,
		@IdentificationTypeId int = NULL,
		@OrganisationTypeId int = NULL,
		@GenderId int = NULL,
		@IsIndividual bit = NULL
 AS
 BEGIN
	UPDATE CreditProviders
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name, Name),
		IdentificationNumber = ISNULL(@IdentificationNumber, IdentificationNumber),
		EmailAddress = ISNULL(@EmailAddress, EmailAddress),
		PhoneNumber = ISNULL(@PhoneNumber, PhoneNumber),
		FaxNumber = ISNULL(@FaxNumber, FaxNumber),
		TypeOtherOfOrganisation = ISNULL(@TypeOtherOfOrganisation, TypeOtherOfOrganisation),
		PostalAddress = ISNULL(@PostalAddress, PostalAddress),
		PostalSuburb = ISNULL(@PostalSuburb, PostalSuburb),
		PostalCity = ISNULL(@PostalCity, PostalCity),
		PostalPostalCode = ISNULL(@PostalPostalCode, PostalPostalCode),
		StreetAddress = ISNULL(@StreetAddress, StreetAddress),
		StreetSuburb = ISNULL(@StreetSuburb, StreetSuburb),
		StreetCity = ISNULL(@StreetCity, StreetCity),
		StreetPostalCode = ISNULL(@StreetPostalCode, StreetPostalCode),
		NotificationAddress = ISNULL(@NotificationAddress, NotificationAddress),
		CountryId = ISNULL(@CountryId, CountryId),
		DealershipId = ISNULL(@DealershipId, DealershipId),
		IdentificationTypeId = ISNULL(@IdentificationTypeId, IdentificationTypeId),
		OrganisationTypeId = ISNULL(@OrganisationTypeId, OrganisationTypeId),
		GenderId = ISNULL(@GenderId, GenderId),
		IsIndividual = ISNULL(@IsIndividual, IsIndividual)
	WHERE
		Id = @Id
END
