USE DealershipApp
GO

ALTER PROC [dbo].[spt_CreditProviders_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(150) = NULL,
		@IdentificationNumber varchar(50) = NULL,
		@EmailAddress varchar(80) = NULL,
		@PhoneNumber varchar(25) = NULL,
		@FaxNumber varchar(20) = NULL,
		@TypeOtherOfOrganisation varchar(50) = NULL,
		@PostalAddress varchar(100) = NULL,
		@PostalSuburb varchar(40) = NULL,
		@PostalCity varchar(40) = NULL,
		@PostalPostalCode varchar(6) = NULL,
		@StreetAddress varchar(100) = NULL,
		@StreetSuburb varchar(40) = NULL,
		@StreetCity varchar(40) = NULL,
		@StreetPostalCode varchar(6) = NULL,
		@NotificationAddress int = NULL,
		@CountryId int = NULL,
		@DealershipId int = NULL,
		@IdentificationTypeId int = NULL,
		@OrganisationTypeId int = NULL,
		@GenderId int = NULL,
		@IsIndividual bit = 0

 AS
 BEGIN
	INSERT INTO CreditProviders
	(
		Deleted,
		Active,
		Name,
		IdentificationNumber,
		EmailAddress,
		PhoneNumber,
		FaxNumber,
		TypeOtherOfOrganisation,
		PostalAddress,
		PostalSuburb,
		PostalCity,
		PostalPostalCode,
		StreetAddress,
		StreetSuburb,
		StreetCity,
		StreetPostalCode,
		NotificationAddress,
		CountryId,
		DealershipId,
		IdentificationTypeId,
		OrganisationTypeId,
		GenderId,
		IsIndividual
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@IdentificationNumber,
		@EmailAddress,
		@PhoneNumber,
		@FaxNumber,
		@TypeOtherOfOrganisation,
		@PostalAddress,
		@PostalSuburb,
		@PostalCity,
		@PostalPostalCode,
		@StreetAddress,
		@StreetSuburb,
		@StreetCity,
		@StreetPostalCode,
		@NotificationAddress,
		@CountryId,
		@DealershipId,
		@IdentificationTypeId,
		@OrganisationTypeId,
		@GenderId,
		@IsIndividual
	)
END
