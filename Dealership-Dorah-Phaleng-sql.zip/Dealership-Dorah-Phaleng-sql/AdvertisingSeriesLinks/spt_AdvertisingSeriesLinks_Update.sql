USE DealershipApp
GO


CREATE PROC [dbo].[spt_AdvertisingSeriesLinks_Update]
		@Id int,
		@Deleted bit = 0,
		@Active bit = 1,
		@AdvertisingItemId int = NULL,
		@MakeId int = NULL,
		@SeriesId int = NULL
 AS
 BEGIN
	UPDATE AdvertisingSeriesLinks
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		AdvertisingItemId = ISNULL(@AdvertisingItemId,AdvertisingItemId),
		MakeId = ISNULL(@MakeId,MakeId),
		SeriesId = ISNULL(@SeriesId,SeriesId)
	WHERE
		Id = @Id
END
