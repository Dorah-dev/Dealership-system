USE DealershipApp
GO

CREATE PROC [dbo].[spt_AdvertisingSeriesLinks_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@AdvertisingItemId int,
		@MakeId int = NULL,
		@SeriesId int = NULL
 AS
 BEGIN
	INSERT INTO AdvertisingSeriesLinks
	(
		Deleted,
		Active,
		AdvertisingItemId,
		MakeId,
		SeriesId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@AdvertisingItemId,
		@MakeId,
		@SeriesId
	)

END
