USE [DealershipApp]
GO

/****** Object:  Table [dbo].[DealerAccessories]    Script Date: 2021/11/20 8:19:16 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DealerAccessories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Description] [varchar](256) NULL,
	[Code] [varchar](64) NULL,
	[BaseCostPrice] [money] NULL,
	[BasePrice] [money] NULL,
	[FitmentTime] [decimal](13, 2) NULL,
	[Check] [int] NULL,
	[AskOnQuote] [bit] NOT NULL,
	[AskOnOTP] [bit] NOT NULL,
	[AskOnCostSheet] [bit] NOT NULL,
	[CanPriceChange] [bit] NOT NULL,
	[IsVatItem] [bit] NOT NULL,
	[IsUpsell] [bit] NOT NULL,
	[IsRetailCalculated] [bit] NOT NULL,
	[IsManufacturerItem] [bit] NOT NULL,
	[IsCompulsory] [bit] NOT NULL,
	[IsApproved] [bit] NOT NULL,
	[DateLastUsed] [datetime] NULL,
	[Rounding] [int] NULL,
	[Markup] [int] NULL,
	[DealershipId] [int] NULL,
	[AccessoryId] [int] NULL,
	[DepartmentTypeId] [int] NULL,
	[DealerAccessoryCategoryId] [int] NULL,
	[AccessoryCategoryId] [int] NULL,
	[ipkExtraCost] [int] NULL,
 CONSTRAINT [PK_DealerAccessories] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_AskOnQuote]  DEFAULT ((0)) FOR [AskOnQuote]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_AskOnOTP]  DEFAULT ((0)) FOR [AskOnOTP]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_AskOnCostSheet]  DEFAULT ((0)) FOR [AskOnCostSheet]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_CanPriceChange]  DEFAULT ((0)) FOR [CanPriceChange]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_IsVatItem]  DEFAULT ((0)) FOR [IsVatItem]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_IsUpsell]  DEFAULT ((0)) FOR [IsUpsell]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_IsRetailCalculated]  DEFAULT ((0)) FOR [IsRetailCalculated]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_IsManufacturerItem]  DEFAULT ((0)) FOR [IsManufacturerItem]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_IsCompulsory]  DEFAULT ((0)) FOR [IsCompulsory]
GO

ALTER TABLE [dbo].[DealerAccessories] ADD  CONSTRAINT [DF_DealerAccessories_IsApproved]  DEFAULT ((0)) FOR [IsApproved]
GO

ALTER TABLE [dbo].[DealerAccessories]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessories_Accessories] FOREIGN KEY([AccessoryId])
REFERENCES [dbo].[Accessories] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessories] CHECK CONSTRAINT [FK_DealerAccessories_Accessories]
GO

ALTER TABLE [dbo].[DealerAccessories]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessories_AccessoryCategories] FOREIGN KEY([AccessoryCategoryId])
REFERENCES [dbo].[AccessoryCategories] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessories] CHECK CONSTRAINT [FK_DealerAccessories_AccessoryCategories]
GO

ALTER TABLE [dbo].[DealerAccessories]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessories_DealerAccessoryCategories] FOREIGN KEY([DealerAccessoryCategoryId])
REFERENCES [dbo].[DealerAccessoryCategories] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessories] CHECK CONSTRAINT [FK_DealerAccessories_DealerAccessoryCategories]
GO

ALTER TABLE [dbo].[DealerAccessories]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessories_Dealerships] FOREIGN KEY([DealershipId])
REFERENCES [dbo].[Dealerships] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessories] CHECK CONSTRAINT [FK_DealerAccessories_Dealerships]
GO

ALTER TABLE [dbo].[DealerAccessories]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessories_DepartmentTypes] FOREIGN KEY([DepartmentTypeId])
REFERENCES [dbo].[DepartmentTypes] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessories] CHECK CONSTRAINT [FK_DealerAccessories_DepartmentTypes]
GO


