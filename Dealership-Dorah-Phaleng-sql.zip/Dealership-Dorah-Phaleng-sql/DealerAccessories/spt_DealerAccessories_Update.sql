USE [DealershipApp]
GO

ALTER PROC [dbo].[spt_DealerAccessories_Update]
	@Id int,
	@Deleted bit = NULL,
	@Active bit = NULL,
    @Description varchar(256) = NULL,
    @Code varchar(64) = NULL,
    @BaseCostPrice money  = NULL,
    @BasePrice money  = NULL,
    @FitmentTime decimal(13,2) = NULL,
    @Check int = NULL,
    @AskOnQuote bit = NULL,
    @AskOnOTP  bit = NULL,
    @AskOnCostSheet bit = NULL,
    @CanPriceChange bit = NULL,
    @IsVatItem bit = NULL,
    @IsUpsell bit = NULL,
    @IsRetailCalculated bit = NULL,
    @IsManufacturerItem bit = NULL,
    @IsCompulsory bit = NULL,
    @IsApproved bit = NULL,
    @DateLastUsed datetime = NULL,
    @Rounding int = NULL,
    @Markup int = NULL,
    @DealershipId int = NULL,
    @AccessoryId int = NULL,
    @DepartmentTypeId int = NULL,
    @DealerAccessoryCategoryId int = NULL,
    @AccessoryCategoryId int = NULL
AS
BEGIN
UPDATE DealerAccessories
 	SET
		[Deleted] = ISNULL(@Deleted, [Deleted]),
		[Active] = ISNULL(@Active, [Active]),
		[Description] = ISNULL(@Description, [Description]),
		[Code] = ISNULL(@Code, [Code]),
		[BaseCostPrice] = ISNULL(@BaseCostPrice, [BaseCostPrice]),
		[BasePrice] = ISNULL(@BasePrice, [BasePrice]),
		[FitmentTime] = ISNULL(@FitmentTime, [FitmentTime]),
		[Check] = ISNULL(@Check, [Check]),
		[AskOnQuote] = ISNULL(@AskOnQuote, [AskOnQuote]),
		[AskOnOTP] = ISNULL(@AskOnOTP, [AskOnOTP]),
		[AskOnCostSheet] = ISNULL(@AskOnCostSheet, [AskOnCostSheet]),
		[CanPriceChange] = ISNULL(@CanPriceChange, [CanPriceChange]),
		[IsVatItem] = ISNULL(@IsVatItem, [IsVatItem]),
		[IsUpsell] = ISNULL(@IsUpsell, [IsUpsell]),
		[IsRetailCalculated] = ISNULL(@IsRetailCalculated, [IsRetailCalculated]),
		[IsManufacturerItem] = ISNULL(@IsManufacturerItem, [IsManufacturerItem]),
		[IsCompulsory] = ISNULL(@IsCompulsory, [IsCompulsory]),
		[IsApproved] = ISNULL(@IsApproved, [IsApproved]),
		[DateLastUsed]= ISNULL(@DateLastUsed, [DateLastUsed]),
		[Rounding] = ISNULL(@Rounding, [Rounding]),
		[MarkUp] = ISNULL(@Markup, [Markup]),
		[DealershipId] = ISNULL(@DealershipId, [DealershipId]),
		[AccessoryId] = ISNULL(@AccessoryId, [AccessoryId]),
		[DepartmentTypeId] = ISNULL(@DepartmentTypeId, [DepartmentTypeId]),
		[DealerAccessoryCategoryId] = ISNULL(@DealerAccessoryCategoryId, [DealerAccessoryCategoryId]),
		[AccessoryCategoryId] = ISNULL(@AccessoryCategoryId, [AccessoryCategoryId])

	WHERE
		Id = @Id
END
