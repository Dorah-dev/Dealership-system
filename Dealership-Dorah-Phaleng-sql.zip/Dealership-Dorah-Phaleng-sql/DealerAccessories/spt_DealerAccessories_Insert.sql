USE [DealershipApp]
GO


ALTER PROC [dbo].[spt_DealerAccessories_Insert]

                  @Deleted bit = 0,
                  @Active bit = 1,
                  @Description varchar(256) = NULL,
                  @Code varchar(64) = NULL,
                  @BaseCostPrice money = NULL,
                  @BasePrice money = NULL,
                  @FitmentTime decimal(13,2) = NULL,
                  @Check int = NULL,
                  @AskOnQuote bit = 0,
                  @AskOnOTP  bit = 0,
                  @AskOnCostSheet bit = 0,
                  @CanPriceChange bit = 0,
                  @IsVatItem bit = 0,
                  @IsUpsell bit = 0,
                  @IsRetailCalculated bit = 0,
                  @IsManufacturerItem bit = 0,
                  @IsCompulsory bit = 0,
                  @IsApproved bit = 0,
                  @DateLastUsed datetime = NULL,
                  @Rounding int = NULL,
                  @Markup int = NULL,
                  @DealershipId int = NULL,
                  @AccessoryId int = NULL,
                  @DepartmentTypeId int = NULL,
                  @DealerAccessoryCategoryId int = NULL,
                  @AccessoryCategoryId int = NULL
AS
BEGIN
	INSERT INTO DealerAccessories
	(
		[Deleted],
		[Active],
    [Description],
    [Code],
    [BaseCostPrice],
    [BasePrice],
    [FitmentTime],
    [Check],
    [AskOnQuote],
    [AskOnOTP],
    [AskOnCostSheet],
    [CanPriceChange],
    [IsVatItem],
    [IsUpsell],
    [IsRetailCalculated],
    [IsManufacturerItem],
    [IsCompulsory],
    [IsApproved],
    [DateLastUsed],
    [Rounding],
    [Markup],
    [DealershipId],
    [AccessoryId],
    [DepartmentTypeId],
    [DealerAccessoryCategoryId],
    [AccessoryCategoryId]
	)
  OUTPUT INSERTED.Id
	VALUES
	(
    @Deleted,
    @Active,
    @Description,
    @Code ,
    @BaseCostPrice,
    @BasePrice,
    @FitmentTime,
    @Check,
    @AskOnQuote,
    @AskOnOTP,
    @AskOnCostSheet,
    @CanPriceChange,
    @IsVatItem,
    @IsUpsell,
    @IsRetailCalculated,
    @IsManufacturerItem,
    @IsCompulsory,
    @IsApproved,
    @DateLastUsed,
    @Rounding,
    @Markup,
    @DealershipId,
    @AccessoryId,
    @DepartmentTypeId,
    @DealerAccessoryCategoryId,
    @AccessoryCategoryId
	)
END
