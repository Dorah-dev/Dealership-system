USE [DealershipApp]
GO

/****** Object:  Table [dbo].[RoleFeatures]    Script Date: 2021/11/20 1:08:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER TABLE [dbo].[CommunicationTypes]
ADD IsSelectable BIT NOT NULL CONSTRAINT [DF_CommunicationTypes_IsSelectable] DEFAULT 0
GO
