USE [DealershipApp]
GO

/****** Object:  Table [dbo].[RoleFeatures]    Script Date: 2017/05/18 1:08:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

UPDATE [dbo].[CommunicationTypes]
SET IsSelectable = 1, DateModified = GETDATE()
WHERE Id = 2 or Id = 3
GO
