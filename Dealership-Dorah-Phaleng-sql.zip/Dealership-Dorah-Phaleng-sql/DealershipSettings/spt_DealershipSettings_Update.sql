USE DealershipApp
GO

ALTER PROC [dbo].[spt_DealershipSettings_Update]
		@Deleted bit = NULL,
		@Active bit = NULL,
		@DealershipId int,
		@ComponentSettingId int,
		@Value varchar(150)
 AS
 BEGIN
	UPDATE DealershipSettings
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Value = ISNULL(@Value,Value)
	WHERE
		DealershipId = @DealershipId and ComponentSettingId = @ComponentSettingId --cannot have more than one entry with same dealership and componentSetting id (compositly unique)
END
