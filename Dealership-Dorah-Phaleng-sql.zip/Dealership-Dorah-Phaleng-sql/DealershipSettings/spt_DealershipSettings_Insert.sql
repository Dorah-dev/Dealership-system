USE DealershipApp
GO

ALTER PROC [dbo].[spt_DealershipSettings_Insert]
		@DealershipId int,
		@ComponentSettingId int,
		@Value varchar(150)
 AS
 BEGIN
	IF (NOT EXISTS(SELECT Id FROM DealershipSettings WHERE DealershipId = @DealershipId and ComponentSettingId = @ComponentSettingId and Deleted = 0))
	BEGIN
		INSERT INTO DealershipSettings
		(
			DealershipId,
			ComponentSettingId,
			Value
		) OUTPUT INSERTED.Id
		VALUES
		(
			@DealershipId,
			@ComponentSettingId,
			@Value
		)
	END
END
