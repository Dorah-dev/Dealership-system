USE DealershipApp
GO

CREATE PROC [dbo].[spt_CustomerRelationshipTypeVehicles_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@CustomerRelationshipTypeId int,
		@CustomerId int,
		@VehicleId int,
		@RelationshipTypeId int
 AS
 BEGIN
 	IF NOT EXISTS(SELECT Id FROM CustomerRelationshipTypeVehicles WHERE CustomerId = @CustomerId and VehicleId = @VehicleId and Deleted = 0)
		BEGIN
			INSERT INTO CustomerRelationshipTypeVehicles
				(
					Deleted,
					Active,
					CustomerRelationshipTypeId,
					CustomerId,
					VehicleId,
					RelationshipTypeId
				) 
				VALUES
				(
					@Deleted,
					@Active,
					@CustomerRelationshipTypeId,
					@CustomerId,
					@VehicleId,
					@RelationshipTypeId
				)
				SELECT SCOPE_IDENTITY()
		END
	ELSE
		BEGIN
			SELECT * FROM CustomerRelationshipTypeVehicles WHERE CustomerId = @CustomerId and VehicleId = @VehicleId and Deleted = 0
		END
END
