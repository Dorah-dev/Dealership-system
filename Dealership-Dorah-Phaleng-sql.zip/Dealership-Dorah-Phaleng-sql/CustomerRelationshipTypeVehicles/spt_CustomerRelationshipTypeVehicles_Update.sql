USE DealershipApp
GO

CREATE PROC [dbo].[spt_CustomerRelationshipTypeVehicles_Update]
		@Deleted bit = NULL,
		@Active bit = NULL,
		@CustomerRelationshipTypeId int,
        @CustomerId int,
        @VehicleId int,
		@RelationshipTypeId int = NULL
 AS
 BEGIN
	UPDATE CustomerRelationshipTypeVehicles
 	SET
 		DateModified = GETDATE(),
 		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		CustomerRelationshipTypeId = ISNULL(@CustomerRelationshipTypeId,CustomerRelationshipTypeId),
		RelationshipTypeId = ISNULL(@RelationshipTypeId,RelationshipTypeId)
	WHERE
		CustomerId = @CustomerId AND VehicleId = @VehicleId
END
