USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_Evaluations_Update]
		@Id int,
	    @Deleted bit = NULL,
		@Active bit = NULL,
		@VehicleId int = NULL,
		@ServiceBookingId int = NULL,
		@ODOMeterReading int = NULL,
		@DealershipId int = NULL,
		@UserId int = NULL,
		@VehicleConditionId int = NULL,
		@EstimatedReplacementTotal money = NULL
AS
BEGIN
UPDATE Evaluations
 	SET
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DateModified = GETDATE(),
		VehicleId = ISNULL(@VehicleId,VehicleId),
		ServiceBookingId = ISNULL(@ServiceBookingId,ServiceBookingId),
		ODOMeterReading = ISNULL(@ODOMeterReading,ODOMeterReading),
		DealershipId = ISNULL(@DealershipId,DealershipId),
		UserId = ISNULL(@UserId,UserId),
		VehicleConditionId = ISNULL(@VehicleConditionId,VehicleConditionId),
		EstimatedReplacementTotal = ISNULL(@EstimatedReplacementTotal,EstimatedReplacementTotal)
	WHERE
		Id = @Id
END
GO
