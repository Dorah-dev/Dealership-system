USE [DealershipApp]
GO

/****** Object:  Table [dbo].[Evaluations]    Script Date: 11/20/2021 2:17:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Evaluations](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[VehicleId] [int] NOT NULL,
	[ServiceBookingId] [int] NULL,
	[ODOMeterReading] [int] NULL,
	[DealershipId] [int] NULL,
	[UserId] [int] NULL,
	[VehicleConditionId] [int] NULL,
	[EstimatedReplacementTotal] [money] NULL,
 CONSTRAINT [PK_Evaluations] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Evaluations] ADD  CONSTRAINT [DF_Evaluations_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[Evaluations] ADD  CONSTRAINT [DF_Evaluations_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[Evaluations] ADD  CONSTRAINT [DF_Evaluations_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[Evaluations]  WITH CHECK ADD  CONSTRAINT [FK_Evaluations_Dealerships] FOREIGN KEY([DealershipId])
REFERENCES [dbo].[Dealerships] ([Id])
GO

ALTER TABLE [dbo].[Evaluations] CHECK CONSTRAINT [FK_Evaluations_Dealerships]
GO

ALTER TABLE [dbo].[Evaluations]  WITH CHECK ADD  CONSTRAINT [FK_Evaluations_ServiceBookings] FOREIGN KEY([ServiceBookingId])
REFERENCES [dbo].[ServiceBookings] ([Id])
GO

ALTER TABLE [dbo].[Evaluations] CHECK CONSTRAINT [FK_Evaluations_ServiceBookings]
GO

ALTER TABLE [dbo].[Evaluations]  WITH CHECK ADD  CONSTRAINT [FK_Evaluations_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO

ALTER TABLE [dbo].[Evaluations] CHECK CONSTRAINT [FK_Evaluations_Users]
GO

ALTER TABLE [dbo].[Evaluations]  WITH CHECK ADD  CONSTRAINT [FK_Evaluations_VehicleConditions] FOREIGN KEY([VehicleConditionId])
REFERENCES [dbo].[VehicleConditions] ([Id])
GO

ALTER TABLE [dbo].[Evaluations] CHECK CONSTRAINT [FK_Evaluations_VehicleConditions]
GO

ALTER TABLE [dbo].[Evaluations]  WITH CHECK ADD  CONSTRAINT [FK_Evaluations_Vehicles] FOREIGN KEY([VehicleId])
REFERENCES [dbo].[Vehicles] ([Id])
GO

ALTER TABLE [dbo].[Evaluations] CHECK CONSTRAINT [FK_Evaluations_Vehicles]
GO
