USE [DealershipApp]
GO


CREATE  PROC [dbo].[spt_Evaluations_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@VehicleId int = NULL,
		@ServiceBookingId int = NULL,
		@ODOMeterReading int = NULL,
		@DealershipId int = NULL,
		@UserId int = NULL,
		@VehicleConditionId int = NULL,
		@EstimatedReplacementTotal money = NULL
AS
BEGIN
	INSERT INTO Evaluations
	(
		Deleted,
		Active,
		VehicleId,
		ServiceBookingId,
		ODOMeterReading,
		DealershipId,
		UserId,
		VehicleConditionId,
		EstimatedReplacementTotal
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@VehicleId,
		@ServiceBookingId,
		@ODOMeterReading,
		@DealershipId,
		@UserId,
		@VehicleConditionId,
		@EstimatedReplacementTotal
	)
END
