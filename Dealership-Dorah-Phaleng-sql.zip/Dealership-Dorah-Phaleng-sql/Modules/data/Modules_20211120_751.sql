Insert into Modules
(Name, Description, Code, ApplicationId)
values
('Admin', 'Admin', 'ADM', 1)
