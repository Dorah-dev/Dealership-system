  UPDATE AddressTypes SET Code = 'HO' WHERE Name = 'Home';
  UPDATE AddressTypes SET Code = 'OF' WHERE Name = 'Office';
  UPDATE AddressTypes SET Code = 'PO' WHERE Name = 'P.O. Box.';
  UPDATE AddressTypes SET Code = 'PB' WHERE Name = 'Private Bag';
  UPDATE AddressTypes SET Code = 'PN' WHERE Name = 'Postnet';
  UPDATE AddressTypes SET Code = 'OT' WHERE Name = 'Other';