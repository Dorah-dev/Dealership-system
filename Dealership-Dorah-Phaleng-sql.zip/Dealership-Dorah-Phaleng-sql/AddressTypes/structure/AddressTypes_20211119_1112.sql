ALTER TABLE [dbo].[AddressTypes]
ADD Code [varchar](10) NOT NULL DEFAULT ''
GO