USE [Toyota]
GO

/****** Object:  Table [dbo].[AddressTypes]    Script Date: 2021/11/19 12:35:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AddressTypes](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](100) NOT NULL,
	[IsPostal] [bit] NOT NULL,
	[IsWork] [bit] NOT NULL,
	[IsHome] [bit] NOT NULL,
	[IsPrivatebag] [bit] NOT NULL,
	[IsPostnet] [bit] NOT NULL,
	[ipkAddressTypeId] [int] NULL,
 CONSTRAINT [PK_AddressTypes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[AddressTypes] ADD  CONSTRAINT [DF_AddressTypes_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[AddressTypes] ADD  CONSTRAINT [DF_AddressTypes_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[AddressTypes] ADD  CONSTRAINT [DF_AddressTypes_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[AddressTypes] ADD  CONSTRAINT [DF_AddressTypes_IsPostal]  DEFAULT ((0)) FOR [IsPostal]
GO

ALTER TABLE [dbo].[AddressTypes] ADD  CONSTRAINT [DF_AddressTypes_IsWork]  DEFAULT ((0)) FOR [IsWork]
GO

ALTER TABLE [dbo].[AddressTypes] ADD  CONSTRAINT [DF_AddressTypes_IsHome]  DEFAULT ((0)) FOR [IsHome]
GO

ALTER TABLE [dbo].[AddressTypes] ADD  CONSTRAINT [DF_AddressTypes_IsPrivatebag]  DEFAULT ((0)) FOR [IsPrivatebag]
GO

ALTER TABLE [dbo].[AddressTypes] ADD  CONSTRAINT [DF_AddressTypes_IsPostnet]  DEFAULT ((0)) FOR [IsPostnet]
GO

