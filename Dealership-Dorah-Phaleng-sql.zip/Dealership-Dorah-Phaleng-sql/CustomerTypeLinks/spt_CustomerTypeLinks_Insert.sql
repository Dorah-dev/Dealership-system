USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerTypeLinks_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@CustomerId int,
		@CustomerTypeId int
 AS
 BEGIN
 	IF NOT EXISTS(SELECT Id FROM CustomerTypeLinks WHERE CustomerId = @CustomerId and CustomerTypeId = @CustomerTypeId and Deleted = 0)
	BEGIN
		INSERT INTO CustomerTypeLinks
			(
				Deleted,
				Active,
				CustomerId,
				CustomerTypeId
			) OUTPUT INSERTED.Id
			VALUES
			(
				@Deleted,
				@Active,
				@CustomerId,
				@CustomerTypeId
			)
	END
END
