USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerTypeLinks_Update]
		@Deleted bit = NULL,
		@Active bit = NULL,
		@CustomerId int,
        @CustomerTypeId int
 AS
 BEGIN
	UPDATE CustomerTypeLinks
 	SET
 		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DateModified = GETDATE()
	WHERE
		CustomerId = @CustomerId AND CustomerTypeId = @CustomerTypeId
END