USE DealershipApp
GO

ALTER PROC [dbo].[spt_Proxies_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@IdentificationNumber varchar(30) = NULL,
		@Surname varchar(50) = NULL,
		@Initial varchar(10) = NULL,
		@Firstname varchar(50) = NULL,
		@CountryId int = NULL,
		@CreditProviderId int = NULL,
		@DealershipId int = NULL,
		@IdentificationTypeId int = NULL,
		@ProxyTypeId int = NULL
 AS
 BEGIN
	UPDATE Proxies
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		IdentificationNumber = ISNULL(@IdentificationNumber, IdentificationNumber),
		Surname = ISNULL(@Surname, Surname),
		Initial = ISNULL(@Initial, Initial),
		Firstname = ISNULL(@Firstname, Firstname),
		CountryId = ISNULL(@CountryId, CountryId),
		CreditProviderId = ISNULL(@CreditProviderId, CreditProviderId),
		DealershipId = ISNULL(@DealershipId, DealershipId),
		IdentificationTypeId = ISNULL(@IdentificationTypeId, IdentificationTypeId),
		ProxyTypeId = ISNULL(@ProxyTypeId, ProxyTypeId)
	WHERE
		Id = @Id
END
