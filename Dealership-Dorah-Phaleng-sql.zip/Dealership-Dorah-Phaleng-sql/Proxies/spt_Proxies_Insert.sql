USE DealershipApp
GO

ALTER PROC [dbo].[spt_Proxies_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@IdentificationNumber varchar(30) = NULL,
		@Surname varchar(50) = NULL,
		@Initial varchar(10) = NULL,
		@Firstname varchar(50) = NULL,
		@CountryId int = NULL,
		@CreditProviderId int = NULL,
		@DealershipId int = NULL,
		@IdentificationTypeId int = NULL,
		@ProxyTypeId int = NULL

 AS
 BEGIN
	INSERT INTO Proxies
	(
		Deleted,
		Active,
		IdentificationNumber,
		Surname,
		Initial,
		Firstname,
		CountryId,
		CreditProviderId,
		DealershipId,
		IdentificationTypeId,
		ProxyTypeId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@IdentificationNumber,
		@Surname,
		@Initial,
		@Firstname,
		@CountryId,
		@CreditProviderId,
		@DealershipId,
		@IdentificationTypeId,
		@ProxyTypeId
	)
END
