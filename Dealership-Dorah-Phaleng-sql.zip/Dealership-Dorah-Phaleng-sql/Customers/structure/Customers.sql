USE [DealershipApp]
GO

/****** Object:  Table [dbo].[Customers]    Script Date: 2021/11/20 1:00:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Customers](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[AccountNumber] [varchar](25) NULL,
	[Initial] [varchar](10) NULL,
	[FirstName] [varchar](100) NULL,
	[Surname] [varchar](100) NULL,
	[IDNumber] [varchar](45) NULL,
	[PassportNumber] [varchar](128) NULL,
	[DateBirthday] [datetime] NULL,
	[CompanyName] [varchar](200) NULL,
	[TradingAsName] [varchar](128) NULL,
	[CompanyReg] [varchar](45) NULL,
	[VatRegNumber] [varchar](128) NULL,
	[JobTitle] [varchar](128) NULL,
	[PreferredName] [varchar](50) NULL,
	[TrafficRegisterNumber] [varchar](30) NULL,
	[DriversLicenseNumber] [varchar](32) NULL,
	[IsTender] [bit] NOT NULL,
	[IsVATRegistered] [bit] NOT NULL,
	[IsCarRental] [bit] NOT NULL,
	[IsSalesExclusion] [bit] NOT NULL,
	[CreatedByUserId] [int] NULL,
	[UserId] [int] NULL,
	[GenderId] [int] NULL,
	[BusinessCategoryId] [int] NULL,
	[CompanyTypeId] [int] NULL,
	[CountryId] [int] NULL,
	[CreatedAtDealershipId] [int] NULL,
	[CustomerSourceId] [int] NULL,
	[IncomeBracketId] [int] NULL,
	[PrimaryLanguageId] [int] NULL,
	[MaritalStatusId] [int] NULL,
	[PreferredDealershipId] [int] NULL,
	[RaceId] [int] NULL,
	[TitleId] [int] NULL,
	[ifkCustomerSourceId] [int] NULL,
	[ifkCreatedBySystemUserId] [int] NULL,
	[ifkCreatedAtDealershipId] [int] NULL,
	[ifkIncomeBracketId] [int] NULL,
	[ifkMaritalStatusId] [int] NULL,
	[ifkRaceId] [int] NULL,
	[ifkTitle] [int] NULL,
	[ifkBusinessCategoryId] [int] NULL,
	[ifkLanguageId] [int] NULL,
	[ifkCountryId] [int] NULL,
	[ifkCompanyTypeId] [int] NULL,
	[ifkPreferredDealershipId] [int] NULL,
	[ipkCustomerId] [int] NULL,
 CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_IsTender]  DEFAULT ((0)) FOR [IsTender]
GO

ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_IsVATRegistered]  DEFAULT ((0)) FOR [IsVATRegistered]
GO

ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_IsCarRental]  DEFAULT ((0)) FOR [IsCarRental]
GO

ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_IsSalesExclusion]  DEFAULT ((0)) FOR [IsSalesExclusion]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_BusinessCategories] FOREIGN KEY([BusinessCategoryId])
REFERENCES [dbo].[BusinessCategories] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_BusinessCategories]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_CompanyTypes] FOREIGN KEY([CompanyTypeId])
REFERENCES [dbo].[CompanyTypes] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_CompanyTypes]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_Countries] FOREIGN KEY([CountryId])
REFERENCES [dbo].[Countries] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_Countries]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_CreatedAtDealership] FOREIGN KEY([CreatedAtDealershipId])
REFERENCES [dbo].[Dealerships] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_CreatedAtDealership]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_CreatedByUser] FOREIGN KEY([CreatedByUserId])
REFERENCES [dbo].[Users] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_CreatedByUser]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_CustomerIncomeBrackets] FOREIGN KEY([IncomeBracketId])
REFERENCES [dbo].[CustomerIncomeBrackets] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_CustomerIncomeBrackets]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_CustomerSources] FOREIGN KEY([CustomerSourceId])
REFERENCES [dbo].[CustomerSources] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_CustomerSources]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_Genders] FOREIGN KEY([GenderId])
REFERENCES [dbo].[Genders] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_Genders]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_Languages] FOREIGN KEY([PrimaryLanguageId])
REFERENCES [dbo].[Languages] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_Languages]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_MaritalStatusses] FOREIGN KEY([MaritalStatusId])
REFERENCES [dbo].[MaritalStatuses] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_MaritalStatusses]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_PreferredDealership] FOREIGN KEY([PreferredDealershipId])
REFERENCES [dbo].[Dealerships] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_PreferredDealership]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_Races] FOREIGN KEY([RaceId])
REFERENCES [dbo].[Races] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_Races]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_Titles] FOREIGN KEY([TitleId])
REFERENCES [dbo].[Titles] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_Titles]
GO

ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [FK_Customers_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO

ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [FK_Customers_Users]
GO


