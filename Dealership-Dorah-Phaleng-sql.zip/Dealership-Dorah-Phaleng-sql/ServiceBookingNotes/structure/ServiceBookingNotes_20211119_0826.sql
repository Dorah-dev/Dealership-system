ALTER TABLE [dbo].[ServiceBookingNotes]
ADD UserId [int] NULL
GO
ALTER TABLE [dbo].[ServiceBookingNotes]  WITH CHECK ADD  CONSTRAINT [FK_ServiceBookingNotes_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO
