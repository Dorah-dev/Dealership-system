USE DealershipApp
GO

ALTER PROC [dbo].[spt_UserRoles_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@UserId int = NULL,
		@RoleId int = NULL
 AS
 BEGIN
	INSERT INTO UserRoles
	(
		Deleted,
		Active,
		UserId,
		RoleId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@UserId,
		@RoleId
	)
END
