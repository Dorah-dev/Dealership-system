USE DealershipApp
GO

CREATE PROC [dbo].[spt_UserRoles_Update]
		@Id int,
		@Deleted bit = 0,
		@Active bit = 1,
		@UserId int = NULL,
		@RoleId int = NULL
 AS
 BEGIN
	UPDATE UserRoles
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		UserId = ISNULL(@UserId, UserId),
		RoleId = ISNULL(@RoleId,RoleId) 
	WHERE
		Id = @Id
END