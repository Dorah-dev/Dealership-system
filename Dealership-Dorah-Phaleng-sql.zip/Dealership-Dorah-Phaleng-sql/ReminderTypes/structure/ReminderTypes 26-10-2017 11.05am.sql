USE [DealershipApp]
GO

/****** Object:  Table [dbo].[ReminderTypes]    Script Date: 2021/11/19 11:14:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ReminderTypes](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](255) NULL,
	[Code] [varchar](32) NULL,
	[SortOrder] [int] NOT NULL,
	[IsReadOnly] [bit] NOT NULL,
	[ApplicationID] [int] NULL,
	[ifkAppCodeId] [int] NULL,
	[ipkReminderTypeId] [int] NULL,
 CONSTRAINT [PK_ReminderTypes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ReminderTypes] ADD  CONSTRAINT [DF_ReminderTypes_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[ReminderTypes] ADD  CONSTRAINT [DF_ReminderTypes_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[ReminderTypes] ADD  CONSTRAINT [DF_ReminderTypes_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[ReminderTypes] ADD  CONSTRAINT [DF_ReminderTypes_SortOrder]  DEFAULT ((0)) FOR [SortOrder]
GO

ALTER TABLE [dbo].[ReminderTypes] ADD  CONSTRAINT [DF_ReminderTypes_IsReadOnly]  DEFAULT ((0)) FOR [IsReadOnly]
GO

