USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_DealerAccessoryModels_Update]
	@Id int,
	@Deleted bit = NULL,
    @Active bit = NULL,
    @DealerAccessoryId int = NULL,
    @MakeId int = NULL,
    @SeriesId int = NULL,
    @ModelId int = NULL,
    @ModelAccessoryId int = NULL,
    @BaseCostPrice money = NULL,
    @BaseRetailPrice money = NULL,
    @DMSCode varchar(50) = NULL
AS
BEGIN
UPDATE DealerAccessoryModels
 	SET
		[Deleted] = ISNULL(@Deleted, [Deleted]),
		[Active] = ISNULL(@Active, [Active]),
		[DealerAccessoryId] = ISNULL(@DealerAccessoryId, [DealerAccessoryId]),
		[MakeId] = ISNULL(@MakeId, [MakeId]),
		[SeriesId] = ISNULL(@SeriesId, [SeriesId]),
		[ModelId] = ISNULL(@ModelId, [ModelId]),
		[ModelAccessoryId] = ISNULL(@ModelAccessoryId, [ModelAccessoryId]),
		[BaseCostPrice] = ISNULL(@BaseCostPrice, [BaseCostPrice]),
		[BaseRetailPrice] = ISNULL(@BaseRetailPrice, [BaseRetailPrice]),
		[DMSCode] = ISNULL(@DMSCode, [DMSCode])
	WHERE
		Id = @Id
END
