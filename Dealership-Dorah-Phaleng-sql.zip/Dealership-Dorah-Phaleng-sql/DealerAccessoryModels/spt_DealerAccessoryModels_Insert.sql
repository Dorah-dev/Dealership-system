USE [DealershipApp]
GO


CREATE PROC [dbo].[spt_DealerAccessoryModels_Insert]
                  @Deleted bit = 0,
                  @Active bit = 1,
                  @DealerAccessoryId int,
                  @MakeId int = NULL,
                  @SeriesId int = NULL,
                  @ModelId int = NULL,
                  @ModelAccessoryId int = NULL,
                  @BaseCostPrice money = NULL,
                  @BaseRetailPrice money = NULL,
                  @DMSCode varchar(50) = NULL
AS
BEGIN
	INSERT INTO DealerAccessoryModels
	(
		[Deleted],
		[Active],
    [DealerAccessoryId],
    [MakeId],
    [SeriesId],
    [ModelId],
    [ModelAccessoryId],
    [BaseCostPrice],
    [BaseRetailPrice],
    [DMSCode]
	)
  OUTPUT INSERTED.Id
	VALUES
	(
    @Deleted,
    @Active,
    @DealerAccessoryId,
    @MakeId ,
    @SeriesId,
    @ModelId,
    @ModelAccessoryId,
    @BaseCostPrice,
    @BaseRetailPrice,
    @DMSCode
	)
END
