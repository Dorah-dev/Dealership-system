USE [DealershipApp]
GO

/****** Object:  Table [dbo].[DealerAccessoryModels]    Script Date: 2021/11/20 8:20:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DealerAccessoryModels](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[DealerAccessoryId] [int] NOT NULL,
	[MakeId] [int] NULL,
	[SeriesId] [int] NULL,
	[ModelId] [int] NULL,
	[ModelAccessoryId] [int] NULL,
	[BaseCostPrice] [money] NULL,
	[BaseRetailPrice] [money] NULL,
	[DMSCode] [varchar](50) NULL,
	[ipkAccessoryModelID] [int] NULL,
 CONSTRAINT [PK_DealerAccessoryModels] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[DealerAccessoryModels] ADD  CONSTRAINT [DF_DealerAccessoryModels_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[DealerAccessoryModels] ADD  CONSTRAINT [DF_DealerAccessoryModels_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[DealerAccessoryModels] ADD  CONSTRAINT [DF_DealerAccessoryModels_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[DealerAccessoryModels]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessoryModels_DealerAccesories] FOREIGN KEY([DealerAccessoryId])
REFERENCES [dbo].[DealerAccessories] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessoryModels] CHECK CONSTRAINT [FK_DealerAccessoryModels_DealerAccesories]
GO

ALTER TABLE [dbo].[DealerAccessoryModels]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessoryModels_Makes] FOREIGN KEY([MakeId])
REFERENCES [dbo].[Makes] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessoryModels] CHECK CONSTRAINT [FK_DealerAccessoryModels_Makes]
GO

ALTER TABLE [dbo].[DealerAccessoryModels]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessoryModels_ModelAccessoryId] FOREIGN KEY([ModelAccessoryId])
REFERENCES [dbo].[ModelAccessories] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessoryModels] CHECK CONSTRAINT [FK_DealerAccessoryModels_ModelAccessoryId]
GO

ALTER TABLE [dbo].[DealerAccessoryModels]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessoryModels_Models] FOREIGN KEY([ModelId])
REFERENCES [dbo].[Models] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessoryModels] CHECK CONSTRAINT [FK_DealerAccessoryModels_Models]
GO

ALTER TABLE [dbo].[DealerAccessoryModels]  WITH CHECK ADD  CONSTRAINT [FK_DealerAccessoryModels_Series] FOREIGN KEY([SeriesId])
REFERENCES [dbo].[Series] ([Id])
GO

ALTER TABLE [dbo].[DealerAccessoryModels] CHECK CONSTRAINT [FK_DealerAccessoryModels_Series]
GO


