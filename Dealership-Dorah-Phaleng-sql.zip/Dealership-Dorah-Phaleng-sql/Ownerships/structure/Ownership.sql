USE [DealershipApp]
GO

/****** Object:  Table [dbo].[Ownership]    Script Date: 2021/11/20 8:18:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Ownership](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[RegNumber] [varchar](20) NULL,
	[OdoMeterReading] [int] NULL,
	[DateSold] [datetime] NULL,
	[IsImported] [bit] NOT NULL,
	[CurrentColour] [varchar](32) NULL,
	[CurrentEngineNumber] [varchar](32) NULL,
	[VehicleDelinkReason] [varchar](1024) NULL,
	[ApplicationId] [int] NULL,
	[CustomerId] [int] NULL,
	[VehicleId] [int] NULL,
	[StaffId] [int] NULL,
	[ifkCustomerId] [int] NULL,
	[ifkSystemUserId] [int] NULL,
	[ifkCustomerVehicleId] [int] NULL,
	[ipkVehicleOwnerId] [int] NULL,
 CONSTRAINT [PK_Ownership] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Ownership] ADD  CONSTRAINT [DF_Ownership_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[Ownership] ADD  CONSTRAINT [DF_Ownership_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[Ownership] ADD  CONSTRAINT [DF_Ownership_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[Ownership] ADD  CONSTRAINT [DF_Ownership_IsImported]  DEFAULT ((0)) FOR [IsImported]
GO

ALTER TABLE [dbo].[Ownership]  WITH CHECK ADD  CONSTRAINT [FK_Ownership_ApplicationId] FOREIGN KEY([ApplicationId])
REFERENCES [dbo].[Applications] ([Id])
GO

ALTER TABLE [dbo].[Ownership] CHECK CONSTRAINT [FK_Ownership_ApplicationId]
GO

ALTER TABLE [dbo].[Ownership]  WITH CHECK ADD  CONSTRAINT [FK_Ownership_Customers] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customers] ([Id])
GO

ALTER TABLE [dbo].[Ownership] CHECK CONSTRAINT [FK_Ownership_Customers]
GO

ALTER TABLE [dbo].[Ownership]  WITH CHECK ADD  CONSTRAINT [FK_Ownership_Staff] FOREIGN KEY([StaffId])
REFERENCES [dbo].[Staff] ([Id])
GO

ALTER TABLE [dbo].[Ownership] CHECK CONSTRAINT [FK_Ownership_Staff]
GO

ALTER TABLE [dbo].[Ownership]  WITH CHECK ADD  CONSTRAINT [FK_Ownership_Vehicles] FOREIGN KEY([VehicleId])
REFERENCES [dbo].[Vehicles] ([Id])
GO

ALTER TABLE [dbo].[Ownership] CHECK CONSTRAINT [FK_Ownership_Vehicles]
GO


