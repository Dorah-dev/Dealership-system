USE DealershipApp
GO

ALTER PROC [dbo].[spt_Ownership_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@RegistrationNumber varchar(20) = NULL,
		@OdoMeterReading int = NULL,
		@DateSold datetime = NULL,
		@IsImported bit = NULL,
		@CurrentColour varchar(32) = NULL,
		@CurrentEngineNumber varchar(32) = NULL,
		@VehicleDelinkReason varchar(1024) = NULL,
		@ApplicationId int = NULL,
		@CustomerId int = NULL,
		@VehicleId int = NULL,
		@StaffId int = NULL
 AS
 BEGIN
	UPDATE Ownership
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		RegistrationNumber = ISNULL(@RegistrationNumber,RegistrationNumber),
		OdoMeterReading = ISNULL(@OdoMeterReading,OdoMeterReading),
		DateSold = ISNULL(@DateSold,DateSold),
		IsImported = ISNULL(@IsImported,IsImported),
		CurrentColour = ISNULL(@CurrentColour,CurrentColour),
		CurrentEngineNumber = ISNULL(@CurrentEngineNumber,CurrentEngineNumber),
		VehicleDelinkReason = ISNULL(@VehicleDelinkReason,VehicleDelinkReason),
		ApplicationId = ISNULL(@ApplicationId,ApplicationId),
		CustomerId = @CustomerId,
		VehicleId = ISNULL(@VehicleId,VehicleId),
		StaffId = ISNULL(@StaffId,StaffId)
	WHERE
		Id = @Id
END