USE DealershipApp
GO

ALTER PROC [dbo].[spt_Ownership_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@RegistrationNumber varchar(20) = NULL,
		@OdoMeterReading int = NULL,
		@DateSold datetime = NULL,
		@IsImported bit = 0,
		@CurrentColour varchar(32) = NULL,
		@CurrentEngineNumber varchar(32) = NULL,
		@VehicleDelinkReason varchar(1024) = NULL,
		@ApplicationId int = NULL,
		@CustomerId int = NULL,
		@VehicleId int = NULL,
		@StaffId int = NULL
 AS
 BEGIN
	INSERT INTO Ownership
	(
		Deleted,
		Active,
		RegistrationNumber,
		OdoMeterReading,
		DateSold,
		IsImported,
		CurrentColour,
		CurrentEngineNumber,
		VehicleDelinkReason,
		ApplicationId,
		CustomerId,
		VehicleId,
		StaffId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@RegistrationNumber,
		@OdoMeterReading,
		@DateSold,
		@IsImported,
		@CurrentColour,
		@CurrentEngineNumber,
		@VehicleDelinkReason,
		@ApplicationId,
		@CustomerId,
		@VehicleId,
		@StaffId
	)
END
