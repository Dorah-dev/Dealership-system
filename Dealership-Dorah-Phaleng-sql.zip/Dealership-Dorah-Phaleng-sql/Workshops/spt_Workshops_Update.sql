USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_WorkShops_Update]
		@Id int,
	    @Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(128) = NULL,
		@TeamCode varchar(50) = NULL,
		@UnitsPerHour int = NULL,
		@LoadPercentage int = NULL,
		@ExpressItemMinutes int = NULL,
		@HasLift bit = NULL,
		@DealershipId int = NULL,
		@WorkshopTypeId int = NULL
AS
BEGIN
UPDATE WorkShops
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted, Deleted),
		Active = ISNULL(@Active, Active),
		Name = ISNULL(@Name, Name),
		TeamCode = ISNULL(@TeamCode, TeamCode),
		UnitsPerHour = ISNULL(@UnitsPerHour, UnitsPerHour),
		LoadPercentage = ISNULL(@LoadPercentage, LoadPercentage),
		ExpressItemMinutes = ISNULL(@ExpressItemMinutes, ExpressItemMinutes),
		HasLift = ISNULL(@HasLift, HasLift),
		DealershipId = ISNULL(@DealershipId, DealershipId),
		WorkshopTypeId = ISNULL(@WorkshopTypeId, WorkshopTypeId)
	WHERE
		Id = @Id
END
GO
