USE [DealershipApp]
GO


CREATE  PROC [dbo].[spt_WorkShops_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(128),
		@TeamCode varchar(50) = NULL,
		@UnitsPerHour int = NULL,
		@LoadPercentage int = NULL,
		@ExpressItemMinutes int = 0,
		@HasLift bit = 0,
		@DealershipId int,
		@WorkshopTypeId int
AS
BEGIN
	INSERT INTO WorkShops
	(
		Deleted,
		Active,
		Name,
		TeamCode,
		UnitsPerHour,
		LoadPercentage,
		ExpressItemMinutes,
		HasLift,
		DealershipId,
		WorkshopTypeId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@TeamCode,
		@UnitsPerHour,
		@LoadPercentage,
		@ExpressItemMinutes,
		@HasLift,
		@DealershipId,
		@WorkshopTypeId
	)
END
