USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerReminders_Insert]
		 @Deleted bit = 0,
		 @Active bit = 1,
		 @ReminderId int,
		 @CustomerId int,
		 @ApplicationId int = NULL,
		 @DealershipId int = NULL,
		 @UserId int
 AS
 BEGIN
	INSERT INTO CustomerReminders
	(
		Deleted,
		Active,
		ReminderId,
		CustomerId,
		ApplicationId,
		DealershipId,
		UserId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@ReminderId,
		@CustomerId,
		@ApplicationId,
		@DealershipId,
		@UserId
	)
END
