ALTER TABLE [dbo].[CustomerReminders]
ADD UserId [int] NULL
GO
ALTER TABLE [dbo].[CustomerReminders]  WITH CHECK ADD  CONSTRAINT [FK_CustomerReminders_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO
