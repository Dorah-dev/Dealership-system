USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerReminders_Update]
	 @Id int,
	 @Deleted bit = NULL,
	 @Active bit = NULL,
	 @ReminderId int = NULL,
	 @CustomerId int = NULL,
 	 @ApplicationId int = NULL,
 	 @DealershipId int = NULL,
	 @UserId int = NULL

 AS
 BEGIN
	UPDATE CustomerReminders
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		ReminderId = ISNULL(@ReminderId, ReminderId),
		CustomerId = ISNULL(@CustomerId, CustomerId),
		ApplicationId = ISNULL(@ApplicationId, ApplicationId),
		DealershipId = ISNULL(@DealershipId, DealershipId),
		UserId = ISNULL(@UserId, UserId)

	WHERE
		Id = @Id
END
