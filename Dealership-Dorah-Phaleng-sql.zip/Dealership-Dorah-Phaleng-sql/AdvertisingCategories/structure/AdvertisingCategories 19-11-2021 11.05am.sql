USE [Toyota]
GO

/****** Object:  Table [dbo].[AdvertisingCategories]    Script Date: 2021/11/19 11:01:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AdvertisingCategories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](128) NULL,
	[Code] [varchar](32) NULL,
	[SortOrder] [int] NOT NULL,
	[AdvertisingCategoryId] [int] NULL,
	[ipkAdSourceCategoryID] [int] NULL,
 CONSTRAINT [PK_AdvertisingCategories] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AdvertisingCategories] ADD  CONSTRAINT [DF_AdvertisingCategories_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[AdvertisingCategories] ADD  CONSTRAINT [DF_AdvertisingCategories_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[AdvertisingCategories] ADD  CONSTRAINT [DF_AdvertisingCategories_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[AdvertisingCategories] ADD  CONSTRAINT [DF_AdvertisingCategories_SortOrder]  DEFAULT ((0)) FOR [SortOrder]
GO

ALTER TABLE [dbo].[AdvertisingCategories]  WITH CHECK ADD  CONSTRAINT [FK_AdvertisingCategories_AdvertisingCategories] FOREIGN KEY([AdvertisingCategoryId])
REFERENCES [dbo].[AdvertisingCategories] ([Id])
GO

ALTER TABLE [dbo].[AdvertisingCategories] CHECK CONSTRAINT [FK_AdvertisingCategories_AdvertisingCategories]
GO

