declare @admin_id int
declare @customer_id int

SET @admin_id = (SELECT Modules.Id FROM Modules WHERE Modules.Code LIKE 'ADM')
SET @customer_id = (SELECT Modules.Id FROM Modules WHERE Modules.Code LIKE 'CUS')

insert into Components (Name, Description, Code, ModuleId)
values ('Organogram', 'Organogram', 'AORG', @admin_id),
('Dealer Groups', 'Dealer Groups', 'ADLORG', @admin_id),
('Customer List', 'Customer List', 'ACUSTLST', @admin_id),
('Customer Single View', 'Customer Single View', 'CCUSTSV', @customer_id),
('Customer Form', 'Customer Form', 'CCUSTFRM', @customer_id),
('Timeline', 'Timeline', 'CTIMELN', @customer_id),
('Garage', 'Garage', 'CGAR', @customer_id),
('Communication Manager', 'Communication Manager', 'CCOMMAN', @customer_id),
('Relationships', 'Relationships', 'CCUSTREL', @customer_id);
