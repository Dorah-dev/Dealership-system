insert into Components
(Name, Description, Code, ModuleId)
values
('Role Manager', 'Role Manager', 'ARM', 1)