USE [DealershipApp]
GO

/****** Object:  Table [dbo].[Countries]    Script Date: 11/20/2021 9:40:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Countries](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](50) NULL,
	[Code] [varchar](50) NULL,
	[PhoneNumberCode] [varchar](25) NULL,
	[IsLeadingZeroOnPhoneNumbers] [bit] NOT NULL,
	[VAT] [decimal](15, 2) NULL,
	[InternationalCode] [varchar](50) NULL,
	[ipkCountryId] [int] NULL,
 CONSTRAINT [PK_Countries] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Countries] ADD  CONSTRAINT [DF_Countries_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[Countries] ADD  CONSTRAINT [DF_Countries_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[Countries] ADD  CONSTRAINT [DF_Countries_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[Countries] ADD  CONSTRAINT [DF_Countries_IsLeadingZeroOnPhoneNumbers]  DEFAULT ((1)) FOR [IsLeadingZeroOnPhoneNumbers]
GO

