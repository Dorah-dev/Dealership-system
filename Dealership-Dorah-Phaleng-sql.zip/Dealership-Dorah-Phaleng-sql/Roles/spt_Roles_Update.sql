USE DealershipApp
GO

ALTER PROC [dbo].[spt_Roles_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(32) = NULL,
		@Description varchar(512) = NULL,
		@Code varchar(10) = NULL
 AS
 BEGIN
	UPDATE Roles
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name,Name),
		Description = ISNULL(@Description,Description),
		Code = ISNULL(@Code,Code)
	WHERE
		Id = @Id
END