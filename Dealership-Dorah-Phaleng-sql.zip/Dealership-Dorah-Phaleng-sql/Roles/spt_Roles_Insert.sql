USE DealershipApp
GO

ALTER PROC [dbo].[spt_Roles_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(32),
		@Description varchar(512) = NULL,
		@Code varchar(10)
 AS
 BEGIN
	INSERT INTO Roles
	(
		Deleted,
		Active,
		Name,
		Description,
		Code
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@Description,
		@Code
	)
END
