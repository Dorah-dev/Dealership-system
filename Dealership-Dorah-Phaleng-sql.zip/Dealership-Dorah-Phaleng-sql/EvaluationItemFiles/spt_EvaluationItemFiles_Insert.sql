USE [DealershipApp]
GO


CREATE  PROC [dbo].[spt_EvaluationItemFiles_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@EvaluationItemId int = NULL,
		@FileId int = NULL
AS
BEGIN
	INSERT INTO EvaluationItemFiles
	(
		Deleted,
		Active,
		EvaluationItemId,
		FileId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@EvaluationItemId,
		@FileId
	)
END
