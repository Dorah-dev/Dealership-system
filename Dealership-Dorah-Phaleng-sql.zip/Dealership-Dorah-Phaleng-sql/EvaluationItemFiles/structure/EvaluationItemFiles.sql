USE [DealershipApp]
GO

/****** Object:  Table [dbo].[EvaluationItemFiles]    Script Date: 20/11/2021 2:18:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[EvaluationItemFiles](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[EvaluationItemId] [int] NOT NULL,
	[FileId] [int] NOT NULL,
 CONSTRAINT [PK_EvaluationItemFiles] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[EvaluationItemFiles] ADD  CONSTRAINT [DF_EvaluationItemFiles_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[EvaluationItemFiles] ADD  CONSTRAINT [DF_EvaluationItemFiles_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[EvaluationItemFiles] ADD  CONSTRAINT [DF_EvaluationItemFiles_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[EvaluationItemFiles]  WITH CHECK ADD  CONSTRAINT [FK_EvaluationItemFiles_EvaluationItems] FOREIGN KEY([EvaluationItemId])
REFERENCES [dbo].[EvaluationItems] ([Id])
GO

ALTER TABLE [dbo].[EvaluationItemFiles] CHECK CONSTRAINT [FK_EvaluationItemFiles_EvaluationItems]
GO

ALTER TABLE [dbo].[EvaluationItemFiles]  WITH CHECK ADD  CONSTRAINT [FK_EvaluationItemFiles_Files] FOREIGN KEY([FileId])
REFERENCES [dbo].[Files] ([Id])
GO

ALTER TABLE [dbo].[EvaluationItemFiles] CHECK CONSTRAINT [FK_EvaluationItemFiles_Files]
GO
