USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_EvaluationItemFiles_Update]
		@Id int,
	    @Deleted bit = NULL,
		@Active bit = NULL,
		@EvaluationItemId int = NULL,
		@FileId int = NULL
AS
BEGIN
UPDATE EvaluationItemFiles
 	SET
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DateModified = GETDATE(),
		EvaluationItemId = ISNULL(@EvaluationItemId,EvaluationItemId),
		FileId = ISNULL(@FileId,FileId)
	WHERE
		Id = @Id
END
GO
