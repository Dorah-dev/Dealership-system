USE DealershipApp
GO

ALTER PROC [dbo].[spt_RoleFeatures_Update]
		@Deleted bit = NULL,
		@Active bit = NULL,
		@RoleId int,
		@FeatureId int
 AS
 BEGIN
	UPDATE RoleFeatures
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active)
	WHERE
		RoleId = @RoleId and FeatureID = @FeatureId --cannot have more than one entry with same role and feature id (compositly unique)
END