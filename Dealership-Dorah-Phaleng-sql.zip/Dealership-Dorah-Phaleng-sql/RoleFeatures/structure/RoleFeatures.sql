USE [DealershipApp]
GO

/****** Object:  Table [dbo].[RoleFeatures]    Script Date: 2021/11/19 1:08:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RoleFeatures](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[RoleId] [int] NOT NULL,
	[FeatureId] [int] NOT NULL,
 CONSTRAINT [PK_RoleFeatures] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[RoleFeatures] ADD  CONSTRAINT [DF_RoleFeatures_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[RoleFeatures] ADD  CONSTRAINT [DF_RoleFeatures_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[RoleFeatures] ADD  CONSTRAINT [DF_RoleFeatures_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[RoleFeatures]  WITH CHECK ADD  CONSTRAINT [FK_RoleFeatures_Features] FOREIGN KEY([FeatureId])
REFERENCES [dbo].[Features] ([Id])
GO

ALTER TABLE [dbo].[RoleFeatures] CHECK CONSTRAINT [FK_RoleFeatures_Features]
GO

ALTER TABLE [dbo].[RoleFeatures]  WITH CHECK ADD  CONSTRAINT [FK_RoleFeatures_Roles] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Roles] ([Id])
GO

ALTER TABLE [dbo].[RoleFeatures] CHECK CONSTRAINT [FK_RoleFeatures_Roles]
GO


