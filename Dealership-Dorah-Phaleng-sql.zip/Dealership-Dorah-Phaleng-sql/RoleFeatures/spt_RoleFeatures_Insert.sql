USE DealershipApp
GO

ALTER PROC [dbo].[spt_RoleFeatures_Insert]
		@RoleId int,
		@FeatureId int
 AS
 BEGIN
	IF (NOT EXISTS(SELECT Id FROM RoleFeatures WHERE RoleId = @RoleId and FeatureId = @FeatureId and Deleted = 0))
	BEGIN
		INSERT INTO RoleFeatures
		(
			RoleId,
			FeatureId
		) OUTPUT INSERTED.Id
		VALUES
		(
			@RoleId,
			@FeatureId
		)
	END
END
