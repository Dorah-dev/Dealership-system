USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_WorkshopStaff_Update]
    @Deleted bit = 0,
		@Active bit = 1,
		@StaffId int,
		@WorkshopId int
 AS
 BEGIN
	UPDATE WorkshopStaff
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active)
	WHERE
		StaffId = @StaffId and WorkshopId = @WorkshopId --cannot have more than one entry with same staff and workshop id
END
