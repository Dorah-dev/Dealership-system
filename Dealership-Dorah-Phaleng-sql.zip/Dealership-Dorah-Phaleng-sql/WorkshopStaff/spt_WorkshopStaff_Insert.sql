USE [DealershipApp]
GO


CREATE PROC [dbo].[spt_WorkshopStaff_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@StaffId int,
		@WorkshopId int
AS
BEGIN
	IF(NOT EXISTS(SELECT Id FROM WorkshopStaff WHERE StaffId = @StaffId AND WorkshopId = @WorkshopId AND Deleted = 0))
	BEGIN
		INSERT INTO WorkshopStaff
		(
			Deleted,
			Active,
			StaffId,
			WorkshopId
		) OUTPUT INSERTED.Id
		VALUES
		(
			@Deleted,
			@Active,
			@StaffId,
			@WorkshopId	
		)
	END
END
