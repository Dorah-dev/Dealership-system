USE DealershipApp
GO

ALTER PROC [dbo].[spt_Users_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@UserName varchar(64) = NULL,
		@Password varchar(64) = NULL,
		@DateLastLogin datetime = NULL
 AS
 BEGIN
	UPDATE Users
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		UserName = ISNULL(@UserName,UserName),
		Password = ISNULL(@Password,Password),
		DateLastLogin = ISNULL(@DateLastLogin,DateLastLogin)
	WHERE
		Id = @Id
END