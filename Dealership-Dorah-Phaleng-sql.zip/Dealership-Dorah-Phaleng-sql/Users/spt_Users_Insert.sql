USE DealershipApp
GO

ALTER PROC [dbo].[spt_Users_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@UserName varchar(64),
		@Password varchar(64),
		@DateLastLogin datetime = NULL
 AS
 BEGIN
	INSERT INTO Users
	(
		Deleted,
		Active,
		UserName,
		Password,
		DateLastLogin
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@UserName,
		@Password,
		@DateLastLogin
	)
END
