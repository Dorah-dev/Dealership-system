USE [DealershipApp]
GO

/****** Object:  Table [dbo].[OpportunityVehicleAccessories]    Script Date: 2021/11/20 8:43:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OpportunityVehicleAccessories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[OpportunityVehicleId] [int] NOT NULL,
	[AccessoryId] [int] NULL,
	[AccessoryDescription] [varchar](255) NULL,
	[AccessorySectionId] [int] NULL,
	[BasePrice] [money] NULL,
	[BaseCostPrice] [money] NULL,
	[IsStandardAccessory] [bit] NOT NULL,
	[OrderNumber] [varchar](50) NULL,
	[IsVatItem] [bit] NOT NULL,
	[IsSundryItem] [bit] NOT NULL,
	[CanPriceChange] [bit] NOT NULL,
	[IsCompulsory] [bit] NOT NULL,
	[AskOnCostSheet] [bit] NOT NULL,
	[AccountingCode] [varchar](32) NULL,
	[IsFinAndInsItem] [bit] NOT NULL,
	[IsMonthlyItem] [bit] NOT NULL,
	[PaymentFrequency] [int] NULL,
	[DateFitment] [datetime] NULL,
	[IsFitmentComplete] [bit] NOT NULL,
	[IsManufacturerItem] [bit] NOT NULL,
	[IsNonFactoryDisclaimer] [bit] NOT NULL,
	[SupplierCode] [varchar](50) NULL,
	[ipkOpportunityVehicleFeatureId] [int] NULL,
 CONSTRAINT [PK_OpportunityVehicleAccessories] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsStandardAccessory]  DEFAULT ((0)) FOR [IsStandardAccessory]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsVatItem]  DEFAULT ((0)) FOR [IsVatItem]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsSundryItem]  DEFAULT ((0)) FOR [IsSundryItem]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_CanPriceChange]  DEFAULT ((0)) FOR [CanPriceChange]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsCompulsory]  DEFAULT ((0)) FOR [IsCompulsory]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_AskOnCostSheet]  DEFAULT ((0)) FOR [AskOnCostSheet]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsFinAndInsItem]  DEFAULT ((0)) FOR [IsFinAndInsItem]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsMonthlyItem]  DEFAULT ((0)) FOR [IsMonthlyItem]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsFitmentComplete]  DEFAULT ((0)) FOR [IsFitmentComplete]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsManufacturerItem]  DEFAULT ((0)) FOR [IsManufacturerItem]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] ADD  CONSTRAINT [DF_OpportunityVehicleAccessories_IsNonFactoryDisclaimer]  DEFAULT ((0)) FOR [IsNonFactoryDisclaimer]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicleAccessories_Accessories] FOREIGN KEY([AccessoryId])
REFERENCES [dbo].[Accessories] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] CHECK CONSTRAINT [FK_OpportunityVehicleAccessories_Accessories]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicleAccessories_AccessorySections] FOREIGN KEY([AccessorySectionId])
REFERENCES [dbo].[AccessorySections] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] CHECK CONSTRAINT [FK_OpportunityVehicleAccessories_AccessorySections]
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicleAccessories_OpportunityVehicles] FOREIGN KEY([OpportunityVehicleId])
REFERENCES [dbo].[OpportunityVehicles] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicleAccessories] CHECK CONSTRAINT [FK_OpportunityVehicleAccessories_OpportunityVehicles]
GO
