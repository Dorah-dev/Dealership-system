USE DealershipApp
GO

ALTER PROC [dbo].[spt_OpportunityVehicleAccessories_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@OpportunityVehicleId int = NULL,
		@AccessoryId int = NULL,
		@AccessoryDescription varchar(255) = NULL,
		@AccessorySectionId int = NULL,
		@BasePrice money = NULL,
		@BaseCostPrice money = NULL,
		@IsStandardAccessory bit = NULL,
		@OrderNumber varchar(50) = NULL,
		@IsVatItem bit = NULL,
		@IsSundryItem bit = NULL,
		@CanPriceChange bit = NULL,
		@IsCompulsory bit = NULL,
		@AskOnCostSheet bit = NULL,
		@AccountingCode varchar(32) = NULL,
		@IsFinAndInsItem bit = NULL,
		@IsMonthlyItem bit = NULL,
		@PaymentFrequency int = NULL,
		@DateFitment datetime = NULL,
		@IsFitmentComplete bit = NULL,
		@IsManufacturerItem bit = NULL,
		@IsNonFactoryDisclaimer bit = NULL,
		@SupplierCode varchar(50) = NULL
 AS
 BEGIN
	UPDATE OpportunityVehicleAccessories
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		OpportunityVehicleId = ISNULL(@OpportunityVehicleId,OpportunityVehicleId),
		AccessoryId = ISNULL(@AccessoryId,AccessoryId),
		AccessoryDescription = ISNULL(@AccessoryDescription,AccessoryDescription),
		AccessorySectionId = ISNULL(@AccessorySectionId,AccessorySectionId),
		BasePrice = ISNULL(@BasePrice,BasePrice),
		BaseCostPrice = ISNULL(@BaseCostPrice,BaseCostPrice),
		IsStandardAccessory = ISNULL(@IsStandardAccessory,IsStandardAccessory),
		OrderNumber = ISNULL(@OrderNumber,OrderNumber),
		IsVatItem = ISNULL(@IsVatItem,IsVatItem),
		IsSundryItem = ISNULL(@IsSundryItem,IsSundryItem),
		CanPriceChange = ISNULL(@CanPriceChange,CanPriceChange),
		IsCompulsory = ISNULL(@IsCompulsory,IsCompulsory),
		AskOnCostSheet = ISNULL(@AskOnCostSheet,AskOnCostSheet),
		AccountingCode = ISNULL(@AccountingCode,AccountingCode),
		IsFinAndInsItem = ISNULL(@IsFinAndInsItem,IsFinAndInsItem),
		IsMonthlyItem = ISNULL(@IsMonthlyItem,IsMonthlyItem),
		PaymentFrequency = ISNULL(@PaymentFrequency,PaymentFrequency),
		DateFitment = ISNULL(@DateFitment,DateFitment),
		IsFitmentComplete = ISNULL(@IsFitmentComplete,IsFitmentComplete),
		IsManufacturerItem = ISNULL(@IsManufacturerItem,IsManufacturerItem),
		IsNonFactoryDisclaimer = ISNULL(@IsNonFactoryDisclaimer,IsNonFactoryDisclaimer),
		SupplierCode = ISNULL(@SupplierCode,SupplierCode)

	WHERE
		Id = @Id
END
