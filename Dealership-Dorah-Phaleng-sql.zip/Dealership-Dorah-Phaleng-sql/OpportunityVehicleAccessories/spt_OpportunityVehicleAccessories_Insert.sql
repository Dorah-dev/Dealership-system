USE DealershipApp
GO

ALTER PROC [dbo].[spt_OpportunityVehicleAccessories_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@OpportunityVehicleId int,
		@AccessoryId int = NULL,
		@AccessoryDescription varchar(255) = NULL,
		@AccessorySectionId int = NULL,
		@BasePrice money = NULL,
		@BaseCostPrice money = NULL,
		@IsStandardAccessory bit = 0,
		@OrderNumber varchar(50) = NULL,
		@IsVatItem bit = 0,
		@IsSundryItem bit = 0,
		@CanPriceChange bit = 0,
		@IsCompulsory bit = 0,
		@AskOnCostSheet bit = 0,
		@AccountingCode varchar(32) = NULL,
		@IsFinAndInsItem bit = 0,
		@IsMonthlyItem bit = 0,
		@PaymentFrequency int = NULL,
		@DateFitment datetime = NULL,
		@IsFitmentComplete bit = 0,
		@IsManufacturerItem bit = 0,
		@IsNonFactoryDisclaimer bit = 0,
		@SupplierCode varchar(50) = NULL
 AS
 BEGIN
	INSERT INTO OpportunityVehicleAccessories
	(
		Deleted,
		Active,
		OpportunityVehicleId,
		AccessoryId,
		AccessoryDescription,
		AccessorySectionId,
		BasePrice,
		BaseCostPrice,
		IsStandardAccessory,
		OrderNumber,
		IsVatItem,
		IsSundryItem,
		CanPriceChange,
		IsCompulsory,
		AskOnCostSheet,
		AccountingCode,
		IsFinAndInsItem,
		IsMonthlyItem,
		PaymentFrequency,
		DateFitment,
		IsFitmentComplete,
		IsManufacturerItem,
		IsNonFactoryDisclaimer,
		SupplierCode
		
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@OpportunityVehicleId,
		@AccessoryId,
		@AccessoryDescription,
		@AccessorySectionId,
		@BasePrice,
		@BaseCostPrice,
		@IsStandardAccessory,
		@OrderNumber,
		@IsVatItem,
		@IsSundryItem,
		@CanPriceChange,
		@IsCompulsory,
		@AskOnCostSheet,
		@AccountingCode,
		@IsFinAndInsItem,
		@IsMonthlyItem,
		@PaymentFrequency,
		@DateFitment,
		@IsFitmentComplete,
		@IsManufacturerItem,
		@IsNonFactoryDisclaimer,
		@SupplierCode
	)
END
