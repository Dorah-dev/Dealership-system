USE [DealershipApp]
GO

/****** Object:  Table [dbo].[MiscInfoTypes]    ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MiscInfoTypes](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](200) NULL,
	[Description] [varchar](500) NULL,
	[Type] [varchar](200) NULL,
	[Data] [varchar](2000) NULL,
	[SortOrder] [int] NOT NULL,
	[Code] [varchar](32) NULL,
	[ipkMiscInfoTypeId] [int] NULL,
 CONSTRAINT [PK_MiscInfoTypes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[MiscInfoTypes] ADD  CONSTRAINT [DF_MiscInfoTypes_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[MiscInfoTypes] ADD  CONSTRAINT [DF_MiscInfoTypes_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[MiscInfoTypes] ADD  CONSTRAINT [DF_MiscInfoTypes_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[MiscInfoTypes] ADD  CONSTRAINT [DF_MiscInfoTypes_SortOrder]  DEFAULT ((0)) FOR [SortOrder]
GO

