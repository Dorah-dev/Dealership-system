USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerNotes_Insert]
		 @Deleted bit = 0,
		 @Active bit = 1,
		 @NoteId int,
		 @CustomerID int,
		 @ApplicationId int = NULL,
		 @DealershipId int = NULL,
		 @CommunicationTypeId int = NULL,
		 @ServiceBookingId int = NULL,
		 @UserId int
 AS
 BEGIN
	INSERT INTO CustomerNotes
	(
		Deleted,
		Active,
		NoteId,
		CustomerID,
		ApplicationId,
		DealershipId,
		CommunicationTypeId,
		ServiceBookingId,
		UserId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@NoteId,
		@CustomerID,
		@ApplicationId,
		@DealershipId,
		@CommunicationTypeId,
		@ServiceBookingId,
		@UserId
	)
END
