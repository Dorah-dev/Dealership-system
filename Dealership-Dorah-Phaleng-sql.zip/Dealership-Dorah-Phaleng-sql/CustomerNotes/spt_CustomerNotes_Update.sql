USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerNotes_Update]
	 @Id int,
	 @Deleted bit = NULL,
	 @Active bit = NULL,
	 @NoteId int = NULL,
 	 @CustomerID int = NULL,
 	 @ApplicationId int = NULL,
 	 @DealershipId int = NULL,
 	 @CommunicationTypeId int = NULL,
 	 @ServiceBookingId int = NULL,
	 @UserId int = NULL

 AS
 BEGIN
	UPDATE CustomerNotes
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		NoteId = ISNULL(@NoteId, NoteId),
		CustomerID = ISNULL(@CustomerID, CustomerID),
		ApplicationId = ISNULL(@ApplicationId, ApplicationId),
		DealershipId = ISNULL(@DealershipId, DealershipId),
		CommunicationTypeId = ISNULL(@CommunicationTypeId, CommunicationTypeId),
		ServiceBookingId = ISNULL(@ServiceBookingId, ServiceBookingId),
		UserId = ISNULL(@UserId, UserId)
	WHERE
		Id = @Id
END
