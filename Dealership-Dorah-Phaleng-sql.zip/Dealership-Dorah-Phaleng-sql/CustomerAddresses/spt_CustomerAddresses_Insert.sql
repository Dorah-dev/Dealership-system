USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerAddresses_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Address1 varchar(128) = NULL,
		@Address2 varchar(128) = NULL,
		@Address3 varchar(128) = NULL,
		@Address4 varchar(128) = NULL,
		@PostalCode varchar(16) = NULL,
		@StreetNumber varchar(32) = NULL,
		@IsUseAsPostal bit = 0,
		@IsNoStreetNumber bit = 0,
		@Latitude varchar(128) = NULL,
		@Longitude varchar(128) = NULL,
		@AddressTypeId int,
		@CountryId int,
		@CustomerId int,
		@IsDropOff bit = 0
 AS
 BEGIN
		INSERT INTO CustomerAddresses
			(
				Deleted,
				Active,
				Address1,
				Address2,
				Address3,
				Address4,
				PostalCode,
				StreetNumber,
				IsUseAsPostal,
				IsNoStreetNumber,
				Latitude,
				Longitude,
				AddressTypeId,
				CountryId,
				CustomerId,
				IsDropOff
			) OUTPUT INSERTED.Id
			VALUES
			(
				@Deleted,
				@Active,
				@Address1,
				@Address2,
				@Address3,
				@Address4,
				@PostalCode,
				@StreetNumber,
				@IsUseAsPostal,
				@IsNoStreetNumber,
				@Latitude,
				@Longitude,
				@AddressTypeId,
				@CountryId,
				@CustomerId,
				@IsDropOff
			)
END
