USE [DealershipApp]
GO

/****** Object:  Table [dbo].[CustomerAddresses]    Script Date: 2021/11/20 11:36:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CustomerAddresses](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Address1] [varchar](128) NULL,
	[Address2] [varchar](128) NULL,
	[Address3] [varchar](128) NULL,
	[Address4] [varchar](128) NULL,
	[PostalCode] [varchar](16) NULL,
	[StreetNumber] [varchar](32) NULL,
	[IsUseAsPostal] [bit] NOT NULL,
	[IsNoStreetNumber] [bit] NOT NULL,
	[Latitude] [varchar](128) NULL,
	[Longitude] [varchar](128) NULL,
	[AddressTypeId] [int] NULL,
	[CountryId] [int] NULL,
	[CustomerId] [int] NULL,
	[ifkAddressTypeId] [int] NULL,
	[ifkCustomerId] [int] NULL,
	[ifkProvinceId] [int] NULL,
	[ifkCountryId] [int] NULL,
	[ipkCustomerAddressId] [int] NULL,
 CONSTRAINT [PK_CustomerAddresses] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[CustomerAddresses] ADD  CONSTRAINT [DF_CustomerAddresses_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[CustomerAddresses] ADD  CONSTRAINT [DF_CustomerAddresses_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[CustomerAddresses] ADD  CONSTRAINT [DF_CustomerAddresses_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[CustomerAddresses] ADD  CONSTRAINT [DF_CustomerAddresses_IsUseAsPostal]  DEFAULT ((0)) FOR [IsUseAsPostal]
GO

ALTER TABLE [dbo].[CustomerAddresses] ADD  CONSTRAINT [DF_CustomerAddresses_IsNoStreetNumber]  DEFAULT ((0)) FOR [IsNoStreetNumber]
GO

ALTER TABLE [dbo].[CustomerAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CustomerAddresses_AddressTypeId] FOREIGN KEY([AddressTypeId])
REFERENCES [dbo].[AddressTypes] ([Id])
GO

ALTER TABLE [dbo].[CustomerAddresses] CHECK CONSTRAINT [FK_CustomerAddresses_AddressTypeId]
GO

ALTER TABLE [dbo].[CustomerAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CustomerAddresses_Countries] FOREIGN KEY([CountryId])
REFERENCES [dbo].[Countries] ([Id])
GO

ALTER TABLE [dbo].[CustomerAddresses] CHECK CONSTRAINT [FK_CustomerAddresses_Countries]
GO

ALTER TABLE [dbo].[CustomerAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CustomerAddresses_Customers] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customers] ([Id])
GO

ALTER TABLE [dbo].[CustomerAddresses] CHECK CONSTRAINT [FK_CustomerAddresses_Customers]
GO

