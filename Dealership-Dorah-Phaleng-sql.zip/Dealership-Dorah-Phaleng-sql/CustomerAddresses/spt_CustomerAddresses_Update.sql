USE DealershipApp
GO

CREATE PROC [dbo].[spt_CustomerAddresses_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@Address1 varchar(128) = NULL,
		@Address2 varchar(128) = NULL,
		@Address3 varchar(128) = NULL,
		@Address4 varchar(128) = NULL,
		@PostalCode varchar(16) = NULL,
		@StreetNumber varchar(32) = NULL,
		@IsUseAsPostal bit = NULL,
		@IsNoStreetNumber bit = NULL,
		@Latitude varchar(128) = NULL,
		@Longitude varchar(128) = NULL,
		@AddressTypeId int = NULL,
		@CountryId int = NULL,
		@IsDropOff bit = NULL
 AS
 BEGIN
	UPDATE CustomerAddresses
 	SET
 		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DateModified = GETDATE(),
		Address1 = ISNULL(@Address1, Address1),
		Address2 = ISNULL(@Address2, Address2),
		Address3 = ISNULL(@Address3, Address3),
		Address4 = ISNULL(@Address4, Address4),
		PostalCode = ISNULL(@PostalCode, PostalCode),
		StreetNumber = ISNULL(@StreetNumber, StreetNumber),
		IsUseAsPostal = ISNULL(@IsUseAsPostal, IsUseAsPostal),
		IsNoStreetNumber = ISNULL(@IsNoStreetNumber, IsNoStreetNumber),
		Latitude = ISNULL(@Latitude, Latitude),
		Longitude = ISNULL(@Longitude, Longitude),
		AddressTypeId = ISNULL(@AddressTypeId, AddressTypeId),
		CountryId = ISNULL(@CountryId, CountryId),
		IsDropOff = ISNULL(@IsDropOff, IsDropOff)
	WHERE
		Id = @Id
END
