USE [DealershipApp]
GO

/****** Object:  Table [dbo].[JobTitleRoles]    Script Date: 2021/11/20 3:40:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[JobTitleRoles](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[JobTitleId] [int] NOT NULL,
	[RoleId] [int] NOT NULL,
 CONSTRAINT [PK_JobTitleRoles] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[JobTitleRoles] ADD  CONSTRAINT [DF_JobTitleRoles_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[JobTitleRoles] ADD  CONSTRAINT [DF_JobTitleRoles_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[JobTitleRoles] ADD  CONSTRAINT [DF_JobTitleRoles_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[JobTitleRoles]  WITH CHECK ADD  CONSTRAINT [FK_JobTitleRoles_JobTitles] FOREIGN KEY([JobTitleId])
REFERENCES [dbo].[JobTitles] ([Id])
GO

ALTER TABLE [dbo].[JobTitleRoles] CHECK CONSTRAINT [FK_JobTitleRoles_JobTitles]
GO

ALTER TABLE [dbo].[JobTitleRoles]  WITH CHECK ADD  CONSTRAINT [FK_JobTitleRoles_Roles] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Roles] ([Id])
GO

ALTER TABLE [dbo].[JobTitleRoles] CHECK CONSTRAINT [FK_JobTitleRoles_Roles]
GO


