USE DealershipApp
GO

ALTER PROC [dbo].[spt_JobTitleRoles_Insert]
		@JobTitleId int,
		@RoleId int
 AS
 BEGIN
	IF NOT EXISTS(SELECT Id FROM JobTitleRoles WHERE JobTitleId = @JobTitleId and RoleId = @RoleId and Deleted = 0)
	BEGIN
		INSERT INTO JobTitleRoles
		(
			JobTitleId,
			RoleId
		) OUTPUT INSERTED.Id
		VALUES
		(
			@JobTitleId,
			@RoleId
		)
	END
END
