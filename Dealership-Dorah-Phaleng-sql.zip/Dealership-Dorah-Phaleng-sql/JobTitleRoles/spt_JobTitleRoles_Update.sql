USE DealershipApp
GO

ALTER PROC [dbo].[spt_JobTitleRoles_Update]
		@Deleted bit = 0,
		@Active bit = 1,
		@JobTitleId int,
		@RoleId int
 AS
 BEGIN
	UPDATE JobTitleRoles
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active)
	WHERE
		JobTitleId = @JobTitleId AND RoleId = @RoleId
END