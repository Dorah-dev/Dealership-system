USE DealershipApp
GO

ALTER PROC [dbo].[spt_Notes_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(32) = NULL,
		@Description varchar(512) = NULL,
		@NoteTypeId int = NULL,
		@UserId int = NULL
 AS
 BEGIN
	UPDATE Notes
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name,Name),
		Description = ISNULL(@Description,Description),
		NoteTypeId = ISNULL(@NoteTypeId,NoteTypeId),
		UserId = ISNULL(@UserId,UserId)
	WHERE
		Id = @Id
END
