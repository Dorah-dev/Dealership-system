USE DealershipApp
GO

ALTER PROC [dbo].[spt_Notes_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(32),
		@Description varchar(512) = NULL,
		@NoteTypeId int,
		@UserId int
 AS
 BEGIN
	INSERT INTO Notes
	(
		Deleted,
		Active,
		Name,
		Description,
		NoteTypeId,
		UserId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@Description,
		@NoteTypeId,
		@UserId
	)
END
