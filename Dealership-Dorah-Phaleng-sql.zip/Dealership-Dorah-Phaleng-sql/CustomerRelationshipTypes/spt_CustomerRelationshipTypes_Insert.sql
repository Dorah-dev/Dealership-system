USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerRelationshipTypes_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@PrimaryCustomerId int,
		@RelatedCustomerId int,
		@RelationshipTypeId int
 AS
 BEGIN
 	IF NOT EXISTS(SELECT Id FROM CustomerRelationshipTypes WHERE PrimaryCustomerId = @PrimaryCustomerId and RelatedCustomerId = @RelatedCustomerId and Deleted = 0)
		BEGIN
			INSERT INTO CustomerRelationshipTypes
				(
					Deleted,
					Active,
					PrimaryCustomerId,
					RelatedCustomerId,
					RelationshipTypeId
				)
				VALUES
				(
					@Deleted,
					@Active,
					@PrimaryCustomerId,
					@RelatedCustomerId,
					@RelationshipTypeId
				)
				SELECT SCOPE_IDENTITY()
		END
	ELSE
		BEGIN
	    	SELECT * FROM CustomerRelationshipTypes WHERE PrimaryCustomerId = @PrimaryCustomerId and RelatedCustomerId = @RelatedCustomerId and Deleted = 0
		END
END
