USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerRelationshipTypes_Update]
		@Deleted bit = NULL,
		@Active bit = NULL,
		@PrimaryCustomerId int,
        @RelatedCustomerId int,
		@RelationshipTypeId int = NULL
 AS
 BEGIN
	UPDATE CustomerRelationshipTypes
 	SET
 		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		RelationshipTypeId = ISNULL(@RelationshipTypeId,RelationshipTypeId),
		DateModified = GETDATE()
	WHERE
		PrimaryCustomerId = @PrimaryCustomerId AND RelatedCustomerId = @RelatedCustomerId
END
