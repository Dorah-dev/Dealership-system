USE [DealershipApp]
GO

/****** Object:  Table [dbo].[CustomerTypes]    Script Date: 2021/11/20 10:37:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CustomerTypes](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](32) NOT NULL,
	[Description] [varchar](512) NULL,
	[Code] [varchar](32) NOT NULL,
	[IsIndividual] [bit] NOT NULL,
	[IsDisplay] [bit] NOT NULL,
 CONSTRAINT [PK_CustomerTypes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CustomerTypes] ADD  CONSTRAINT [DF_CustomerTypes_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[CustomerTypes] ADD  CONSTRAINT [DF_CustomerTypes_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[CustomerTypes] ADD  CONSTRAINT [DF_CustomerTypes_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[CustomerTypes] ADD  DEFAULT ((1)) FOR [IsIndividual]
GO

ALTER TABLE [dbo].[CustomerTypes] ADD  DEFAULT ((1)) FOR [IsDisplay]
GO

