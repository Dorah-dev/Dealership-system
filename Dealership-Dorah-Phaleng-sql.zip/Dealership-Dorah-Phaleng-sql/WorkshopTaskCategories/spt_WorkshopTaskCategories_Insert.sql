USE [DealershipApp]
GO


CREATE PROC [dbo].[spt_WorkshopTaskCategories_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@IsPrimaryTask bit = 0,
		@TaskCategoryId int,
		@WorkshopId int
AS
BEGIN
	INSERT INTO WorkshopTaskCategories
	(
        Deleted,
        Active,
        IsPrimaryTask,
        TaskCategoryId,
        WorkshopId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@IsPrimaryTask,
		@TaskCategoryId,
		@WorkshopId
	)
END
