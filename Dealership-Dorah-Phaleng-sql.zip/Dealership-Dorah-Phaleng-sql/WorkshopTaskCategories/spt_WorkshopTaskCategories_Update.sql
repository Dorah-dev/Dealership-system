USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_WorkshopTaskCategories_Update]
		@IsPrimaryTask bit = 0,
		@Deleted bit = 0,
		@Active bit = 0,
		@TaskCategoryId int,
		@WorkshopId int
 AS
 BEGIN
	UPDATE WorkshopTaskCategories
 	SET
 		IsPrimaryTask = ISNULL(IsPrimaryTask, @IsPrimaryTask),
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active)
	WHERE
		TaskCategoryId = @TaskCategoryId and WorkshopId = @WorkshopId
END