USE DealershipApp
GO

ALTER PROC [dbo].[spt_UserActivity_Insert]
    @Deleted bit = 0,
    @Active bit = 1,
    @UserId int,
    @Name varchar(250),
    @ApplicationId int
AS
BEGIN
  INSERT INTO UserActivity
  (
    Deleted,
	  Active,
    UserId,
    Name,
    ApplicationId
  ) OUTPUT INSERTED.Id
  VALUES
  (
	@Deleted,
	@Active,
    @UserId,
    @Name,
    @ApplicationId
  )
END
