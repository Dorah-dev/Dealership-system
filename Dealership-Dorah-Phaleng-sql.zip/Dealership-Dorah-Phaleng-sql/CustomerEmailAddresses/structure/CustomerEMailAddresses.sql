USE [DealershipApp]
GO

/****** Object:  Table [dbo].[CustomerEMailAddresses]    Script Date: 20/11/2021 11:53:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CustomerEMailAddresses](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[EMailAddress] [varchar](128) NULL,
	[IsDuplicate] [bit] NOT NULL,
	[IsVerified] [bit] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[EMailAddressTypeId] [int] NOT NULL,
	[ifkEMailAddressTypeId] [int] NULL,
	[ifkCustomerId] [int] NULL,
	[ipkCustomerEMailAddressId] [int] NULL,
 CONSTRAINT [PK_CustomerEMailAddresses] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CustomerEMailAddresses] ADD  CONSTRAINT [DF_CustomerEMailAddresses_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[CustomerEMailAddresses] ADD  CONSTRAINT [DF_CustomerEMailAddresses_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[CustomerEMailAddresses] ADD  CONSTRAINT [DF_CustomerEMailAddresses_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[CustomerEMailAddresses] ADD  CONSTRAINT [DF_CustomerEMailAddresses_IsDuplicate]  DEFAULT ((0)) FOR [IsDuplicate]
GO

ALTER TABLE [dbo].[CustomerEMailAddresses] ADD  CONSTRAINT [DF_CustomerEMailAddresses_IsVerified]  DEFAULT ((0)) FOR [IsVerified]
GO

ALTER TABLE [dbo].[CustomerEMailAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CustomerEMailAddresses_EMailAddressTypes] FOREIGN KEY([EMailAddressTypeId])
REFERENCES [dbo].[EMailAddressTypes] ([Id])
GO

ALTER TABLE [dbo].[CustomerEMailAddresses] CHECK CONSTRAINT [FK_CustomerEMailAddresses_EMailAddressTypes]
GO

ALTER TABLE [dbo].[CustomerEMailAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CustomersCustomerEMailAddresses_Customers] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customers] ([Id])
GO

ALTER TABLE [dbo].[CustomerEMailAddresses] CHECK CONSTRAINT [FK_CustomersCustomerEMailAddresses_Customers]
GO

