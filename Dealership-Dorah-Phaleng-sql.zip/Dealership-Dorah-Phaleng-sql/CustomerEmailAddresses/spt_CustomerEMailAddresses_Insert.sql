USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerEMailAddresses_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@EMailAddress varchar(128),
		@IsDuplicate bit = 0,
		@IsVerified bit = 0,
		@CustomerId int,
		@EMailAddressTypeId int
 AS
 BEGIN
	IF (NOT EXISTS(SELECT Id FROM CustomerEMailAddresses WHERE CustomerId = @CustomerId and EMailAddressTypeId = @EMailAddressTypeId and Deleted = 0))
	BEGIN
		INSERT INTO CustomerEMailAddresses
		(
			Deleted,
			Active,
			EMailAddress,
			IsDuplicate,
			IsVerified,
			CustomerId,
			EMailAddressTypeId
		) OUTPUT INSERTED.Id
		VALUES
		(
			@Deleted,
			@Active,
			@EMailAddress,
			@IsDuplicate,
			@IsVerified,
			@CustomerId,
			@EMailAddressTypeId
		)
	END
END
