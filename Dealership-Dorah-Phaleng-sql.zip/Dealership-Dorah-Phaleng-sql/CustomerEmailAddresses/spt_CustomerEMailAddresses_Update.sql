USE DealershipApp
GO

CREATE PROC [dbo].[spt_CustomerEMailAddresses_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@EMailAddress varchar(128) = NULL,
		@IsDuplicate bit = NULL,
		@IsVerified bit = NULL,
		@CustomerId int = NULL,
		@EMailAddressTypeId int = NULL
 AS
 BEGIN
	UPDATE CustomerEMailAddresses
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		EMailAddress = ISNULL(@EMailAddress,EMailAddress),
		IsDuplicate = ISNULL(@IsDuplicate,IsDuplicate),
		IsVerified = ISNULL(@IsVerified,IsVerified),
		CustomerId = ISNULL(@CustomerId,CustomerId),
		EMailAddressTypeId = ISNULL(@EMailAddressTypeId,EMailAddressTypeId)

	WHERE
		Id = @Id 
END