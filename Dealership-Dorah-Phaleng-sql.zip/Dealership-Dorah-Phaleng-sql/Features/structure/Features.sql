USE [DealershipApp]
GO

/****** Object:  Table [dbo].[Features]    Script Date: 2021/11/20 1:17:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Features](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](32) NOT NULL,
	[Description] [varchar](512) NULL,
	[ComponentId] [int] NULL,
	[Code] [varchar](10) NOT NULL,
 CONSTRAINT [PK_Features] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Features] ADD  CONSTRAINT [DF_Features_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[Features] ADD  CONSTRAINT [DF_Features_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[Features] ADD  CONSTRAINT [DF_Features_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[Features]  WITH CHECK ADD  CONSTRAINT [FK_Features_Components] FOREIGN KEY([ComponentId])
REFERENCES [dbo].[Components] ([Id])
GO

ALTER TABLE [dbo].[Features] CHECK CONSTRAINT [FK_Features_Components]
GO


