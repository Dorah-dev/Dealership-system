USE DealershipApp
GO

ALTER PROC [dbo].[spt_Features_Update]
		@Id int,
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(32) = NULL,
		@Description varchar(512) = NULL,
		@Code varchar(10) = NULL,
		@ComponentId int = NULL
 AS
 BEGIN
	UPDATE Features
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name,Name),
		Description = ISNULL(@Description,Description),
		Code = ISNULL(@Code,Code),
		ComponentId = ISNULL(@ComponentId,ComponentId)
	WHERE
		Id = @Id
END