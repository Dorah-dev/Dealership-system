USE [DealershipApp]
GO

ALTER PROC [dbo].[spt_CustomerInterests_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@CustomerId int,
		@InterestId int
 AS
 BEGIN
 	IF NOT EXISTS(SELECT Id FROM CustomerInterests WHERE CustomerId = @CustomerId and InterestId = @InterestId)
	BEGIN
		INSERT INTO CustomerInterests
			(
				Deleted,
				Active,
				CustomerId,
				InterestId
			) OUTPUT INSERTED.Id 
			VALUES
			(
				@Deleted,
				@Active,
				@CustomerId,
				@InterestId
			)
	END
	ELSE --Exists - update
	BEGIN
		UPDATE CustomerInterests
 		SET
 			Deleted = ISNULL(@Deleted,Deleted),
			Active = ISNULL(@Active,Active),
			DateModified = GETDATE()
		WHERE
			CustomerId = @CustomerId AND InterestId = @InterestId
	END
END
