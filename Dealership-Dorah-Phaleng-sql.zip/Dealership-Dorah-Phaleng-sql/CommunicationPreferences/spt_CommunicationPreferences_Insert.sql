USE [DealershipApp]
GO

ALTER PROCEDURE  [dbo].[spt_CommunicationPreferences_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@IsOptOut bit = 0,
		@CommunicationTypeId int = NULL,
		@CustomerId int,
		@CommunicationMessageTypeId int

AS
 	IF NOT EXISTS(SELECT Id FROM CommunicationPreferences WHERE CustomerId = @CustomerId and CommunicationMessageTypeId = @CommunicationMessageTypeId and Deleted = 0)
 BEGIN
	INSERT INTO CommunicationPreferences
		(
			Deleted,
			Active,
			IsOptOut,
			CommunicationTypeId,
			CustomerId,
			CommunicationMessageTypeId
		) OUTPUT INSERTED.Id
		VALUES
		(
			@Deleted,
			@Active,
			@IsOptOut,
			@CommunicationTypeId,
			@CustomerId,
			@CommunicationMessageTypeId
		)
END
