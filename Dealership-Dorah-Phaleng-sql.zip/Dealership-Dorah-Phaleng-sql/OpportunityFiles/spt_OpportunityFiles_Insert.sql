USE [DealershipApp]
GO


CREATE PROC [dbo].[spt_OpportunityFiles_Insert]

                  @Deleted bit = 0,
                  @Active bit = 1,
                  @FileId int = NULL,
                  @OpportunityId int = NULL,
                  @OpportunityVehicleId int = NULL

AS
BEGIN
	INSERT INTO OpportunityFiles
	(
		[Deleted],
		[Active],
    [FileId],
    [OpportunityId],
    [OpportunityVehicleId]
	)
  OUTPUT INSERTED.Id
	VALUES
	(
    @Deleted,
    @Active,
    @FileId,
    @OpportunityId,
    @OpportunityVehicleId
	)
END
