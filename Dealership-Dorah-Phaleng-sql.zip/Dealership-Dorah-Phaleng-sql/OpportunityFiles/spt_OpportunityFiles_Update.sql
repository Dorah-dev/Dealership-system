USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_OpportunityFiles_Update]
	@Id int,
	@Deleted bit = NULL,
	@Active bit = NULL,
  @FileId int = NULL,
  @OpportunityId int = NULL,
  @OpportunityVehicleId int = NULL

AS
BEGIN
UPDATE OpportunityFiles
 	SET
		[Deleted] = ISNULL(@Deleted, [Deleted]),
		[Active] = ISNULL(@Active, [Active]),
		[FileId] = ISNULL(@FileId, [FileId]),
		[OpportunityId] = ISNULL(@OpportunityId, [OpportunityId]),
		[OpportunityVehicleId] = ISNULL(@OpportunityVehicleId, [OpportunityVehicleId])

	WHERE
		Id = @Id
END
