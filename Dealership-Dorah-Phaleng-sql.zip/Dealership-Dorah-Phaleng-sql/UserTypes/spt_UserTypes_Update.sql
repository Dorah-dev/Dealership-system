USE DealershipApp
GO

CREATE PROC [dbo].[spt_UserTypes_Update]
		@Id int,
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(32) = NULL,
		@Description varchar(512) = NULL
 AS
 BEGIN
	UPDATE UserTypes
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name,Name),
		Description = ISNULL(@Description,Description)
	WHERE
		Id = @Id
END