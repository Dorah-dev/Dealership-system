USE DealershipApp
GO

ALTER PROC [dbo].[spt_UserTypes_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(32) = NULL,
		@Description varchar(512) = NULL
 AS
 BEGIN
	INSERT INTO UserTypes
	(
		Deleted,
		Active,
		Name,
		Description
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@Description
	)
END
