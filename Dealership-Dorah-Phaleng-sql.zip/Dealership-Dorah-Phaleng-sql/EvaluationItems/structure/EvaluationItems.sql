

USE [DealershipApp]
GO

/****** Object:  Table [dbo].[EvaluationItems]    Script Date: 20/11/2021 2:19:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[EvaluationItems](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[EvaluationId] [int] NOT NULL,
	[DamageCategoryId] [int] NOT NULL,
	[EstimatedReplacementValue] [money] NULL,
	[Description] [varchar](500) NULL,
	[IsInterior] [bit] NOT NULL,
	[XCoordinate] [decimal](22, 18) NOT NULL,
	[YCoordinate] [decimal](22, 18) NOT NULL,
	[ZCoordinate] [decimal](22, 18) NOT NULL,
	[EvaluationModelId] [int] NOT NULL,
 CONSTRAINT [PK_EvaluationItems] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[EvaluationItems] ADD  CONSTRAINT [DF_EvaluationItems_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[EvaluationItems] ADD  CONSTRAINT [DF_EvaluationItems_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[EvaluationItems] ADD  CONSTRAINT [DF_EvaluationItems_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[EvaluationItems] ADD  CONSTRAINT [DF_EvaluationItems_IsInterior]  DEFAULT ((0)) FOR [IsInterior]
GO

ALTER TABLE [dbo].[EvaluationItems]  WITH CHECK ADD  CONSTRAINT [FK_EvaluationItems_DamageCategories] FOREIGN KEY([DamageCategoryId])
REFERENCES [dbo].[DamageCategories] ([Id])
GO

ALTER TABLE [dbo].[EvaluationItems] CHECK CONSTRAINT [FK_EvaluationItems_DamageCategories]
GO

ALTER TABLE [dbo].[EvaluationItems]  WITH CHECK ADD  CONSTRAINT [FK_EvaluationItems_EvaluationModels] FOREIGN KEY([EvaluationModelId])
REFERENCES [dbo].[EvaluationModels] ([Id])
GO

ALTER TABLE [dbo].[EvaluationItems] CHECK CONSTRAINT [FK_EvaluationItems_EvaluationModels]
GO

ALTER TABLE [dbo].[EvaluationItems]  WITH CHECK ADD  CONSTRAINT [FK_EvaluationItems_Evaluations] FOREIGN KEY([EvaluationId])
REFERENCES [dbo].[Evaluations] ([Id])
GO

ALTER TABLE [dbo].[EvaluationItems] CHECK CONSTRAINT [FK_EvaluationItems_Evaluations]
GO
