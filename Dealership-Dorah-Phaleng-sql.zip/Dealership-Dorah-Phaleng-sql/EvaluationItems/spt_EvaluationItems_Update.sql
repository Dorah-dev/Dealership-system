USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_EvaluationItems_Update]
		@Id int,
	    @Deleted bit = NULL,
		@Active bit = NULL,
		@EvaluationId int = NULL,
		@DamageCategoryId int = NULL,
		@EstimatedReplacementValue money = NULL,
		@Description varchar(32) = NULL,
		@IsInterior bit = 0,
		@XCoordinate decimal(15,2) = NULL,
		@YCoordinate decimal(15,2) = NULL,
		@ZCoordinate decimal(15,2) = NULL,
		@EvaluationModelId int = NULL
AS
BEGIN
UPDATE EvaluationItems
 	SET
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DateModified = GETDATE(),
		EvaluationId = ISNULL(@EvaluationId,EvaluationId),
		DamageCategoryId = ISNULL(@DamageCategoryId,DamageCategoryId),
		EstimatedReplacementValue = ISNULL(@EstimatedReplacementValue,EstimatedReplacementValue),
		Description = ISNULL(@Description,Description),
		IsInterior = ISNULL(@IsInterior,IsInterior),
		XCoordinate = ISNULL(@XCoordinate,XCoordinate),
		YCoordinate = ISNULL(@YCoordinate,YCoordinate),
		ZCoordinate = ISNULL(@ZCoordinate,ZCoordinate),
		EvaluationModelId = ISNULL(@EvaluationModelId,EvaluationModelId)
	WHERE
		Id = @Id
END
GO
