USE [DealershipApp]
GO


CREATE  PROC [dbo].[spt_EvaluationItems_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@EvaluationId int = NULL,
		@DamageCategoryId int = NULL,
		@EstimatedReplacementValue money = NULL,
		@Description varchar(32) = NULL,
		@IsInterior bit = 0,
		@XCoordinate decimal(22,18) = NULL,
		@YCoordinate decimal(22,18) = NULL,
		@ZCoordinate decimal(22,18) = NULL,
		@EvaluationModelId int = NULL
AS
BEGIN
	INSERT INTO EvaluationItems
	(
		Deleted,
		Active,
		EvaluationId,
		DamageCategoryId,
		EstimatedReplacementValue,
		Description,
		IsInterior,
		XCoordinate,
		YCoordinate,
		ZCoordinate,
		EvaluationModelId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@EvaluationId,
		@DamageCategoryId,
		@EstimatedReplacementValue,
		@Description,
		@IsInterior,
		@XCoordinate,
		@YCoordinate,
		@ZCoordinate,
		@EvaluationModelId
	)
END
