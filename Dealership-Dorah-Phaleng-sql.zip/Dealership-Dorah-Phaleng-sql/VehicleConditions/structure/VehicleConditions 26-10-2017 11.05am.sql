USE [DealershipApp]
GO

/****** Object:  Table [dbo].[VehicleConditions]    Script Date: 2021/11/19 11:23:25 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[VehicleConditions](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](100) NULL,
	[SortOrder] [int] NOT NULL,
	[ipkUsedVehicleConditionId] [int] NULL,
 CONSTRAINT [PK_VehicleConditions] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[VehicleConditions] ADD  CONSTRAINT [DF_VehicleConditions_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[VehicleConditions] ADD  CONSTRAINT [DF_VehicleConditions_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[VehicleConditions] ADD  CONSTRAINT [DF_VehicleConditions_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[VehicleConditions] ADD  CONSTRAINT [DF_VehicleConditions_SortOrder]  DEFAULT ((0)) FOR [SortOrder]
GO

