Insert into VehicleConditions
(Name, SortOrder)
values
('Poor', 1),
('Fair', 2),
('Good', 3),
('Very Good', 4),
('Excellent', 5)
