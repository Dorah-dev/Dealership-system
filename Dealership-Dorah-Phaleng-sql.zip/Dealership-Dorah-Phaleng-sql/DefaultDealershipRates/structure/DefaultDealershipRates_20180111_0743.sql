USE [DealershipApp]
GO
EXEC sp_rename 'DefaultDealershipRates.DivCode', 'Code';
GO
