USE DealershipApp
GO

ALTER PROC [dbo].[spt_DefaultDealershipRates_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@DealershipId int = NULL,
		@Code varchar(25) = NULL,
		@ConsumableRate money = NULL
 AS
 BEGIN
	UPDATE DefaultDealershipRates
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DealershipId = ISNULL(@DealershipId,DealershipId),
		Code = ISNULL(@Code,Code),
		ConsumableRate = ISNULL(@ConsumableRate,ConsumableRate)
	WHERE
		Id = @Id
END
