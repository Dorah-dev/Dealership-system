USE DealershipApp
GO

ALTER PROC [dbo].[spt_DefaultDealershipRates_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@DealershipId int,
		@Code varchar(25) = NULL,
		@ConsumableRate money = NULL
 AS
 BEGIN
	INSERT INTO DefaultDealershipRates
	(
		Deleted,
		Active,
		DealershipId,
		Code,
		ConsumableRate
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@DealershipId,
		@Code,
		@ConsumableRate
	)
END
