USE DealershipApp
GO

ALTER PROC [dbo].[spt_Opportunities_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@DealershipId int = NULL,
		@CustomerId int = NULL,
		@StaffId int = NULL,
		@LockedbyStaffId int = NULL,
		@AdvertisingItemId int = NULL,
		@SalesStepId int = NULL,
		@DateDue datetime = NULL,
		@DateAccepted datetime = NULL,
		@DateLocked datetime = NULL,
		@DateCompleteChanged datetime = NULL,
		@IsAssigned bit = 0,
		@IsCompleted bit = 0,
		@IsQuoteApproved bit = 0,
		@GroupingNumber int = NULL
 AS
 BEGIN
	INSERT INTO Opportunities
	(
		Deleted,
		Active,
		DealershipId,
		CustomerId,
		StaffId,
		LockedbyStaffId,
		AdvertisingItemId,
		SalesStepId,
		DateDue,
		DateAccepted,
		DateLocked,
		DateCompleteChanged,
		IsAssigned,
		IsCompleted,
		IsQuoteApproved,
		GroupingNumber
		
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@DealershipId,
		@CustomerId,
		@StaffId,
		@LockedbyStaffId,
		@AdvertisingItemId,
		@SalesStepId,
		@DateDue,
		@DateAccepted,
		@DateLocked,
		@DateCompleteChanged,
		@IsAssigned,
		@IsCompleted,
		@IsQuoteApproved,
		@GroupingNumber
	)
END
