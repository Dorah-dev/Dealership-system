USE DealershipApp
GO

ALTER PROC [dbo].[spt_Opportunities_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@DealershipId int = NULL,
		@CustomerId int = NULL,
		@StaffId int = NULL,
		@LockedbyStaffId int = NULL,
		@AdvertisingItemId int = NULL,
		@SalesStepId int = NULL,
		@DateDue datetime = NULL,
		@DateAccepted datetime = NULL,
		@DateLocked datetime = NULL,
		@DateCompleteChanged datetime = NULL,
		@IsAssigned bit = NULL,
		@IsCompleted bit = NULL,
		@IsQuoteApproved bit = NULL,
		@GroupingNumber int = NULL
 AS
 BEGIN
	UPDATE Opportunities
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DealershipId = ISNULL(@DealershipId,DealershipId),
		CustomerId = ISNULL(@CustomerId,CustomerId),
		StaffId = ISNULL(@StaffId,StaffId),
		LockedbyStaffId = ISNULL(@LockedbyStaffId,LockedbyStaffId),
		AdvertisingItemId = ISNULL(@AdvertisingItemId,AdvertisingItemId),
		SalesStepId = ISNULL(@SalesStepId,SalesStepId),
		DateDue = ISNULL(@DateDue,DateDue),
		DateAccepted = ISNULL(@DateAccepted,DateAccepted),
		DateLocked = ISNULL(@DateLocked,DateLocked),
		DateCompleteChanged = ISNULL(@DateCompleteChanged,DateCompleteChanged),
		IsAssigned = ISNULL(@IsAssigned,IsAssigned),
		IsCompleted = ISNULL(@IsCompleted,IsCompleted),
		IsQuoteApproved = ISNULL(@IsQuoteApproved,IsQuoteApproved),
		GroupingNumber = ISNULL(@GroupingNumber,GroupingNumber)

	WHERE
		Id = @Id
END
