USE [DealershipApp]
GO


CREATE PROC [dbo].[spt_ModelAccessories_Insert]

                  @Deleted bit = 0,
                  @Active bit = 1,
                  @BaseCostPrice money  = NULL,
                  @BasePrice money = NULL,
                  @DateRunIn datetime = NULL,
                  @DateRunOut datetime = NULL,
                  @Sequence int = NULL,
                  @Quantity int = NULL,
                  @FitmentTime decimal(13,2) = NULL,
                  @Check int = NULL,
                  @IsImported bit = 0,
                  @IsStandard bit = 0,
                  @IsCompulsory bit = 0,
                  @AskOnQuote bit = 0,
                  @AskOnOTP bit = 0,
                  @IsEditPrice bit = 0,
                  @AccessoryId int = NULL,
                  @ModelId int = NULL

AS
BEGIN
  INSERT INTO ModelAccessories
  (
    [Deleted],
    [Active],
    [BaseCostPrice],
    [BasePrice],
    [DateRunIn],
    [DateRunOut],
    [Sequence],
    [Quantity],
    [FitmentTime],
    [Check],
    [IsImported],
    [IsStandard],
    [IsCompulsory],
    [AskOnQuote],
    [AskOnOTP],
    [IsEditPrice],
    [AccessoryId],
    [ModelId]

  ) OUTPUT INSERTED.Id
  VALUES
  (
    @Deleted,
    @Active,
    @BaseCostPrice,
    @BasePrice,
    @DateRunIn,
    @DateRunOut,
    @Sequence,
    @Quantity,
    @FitmentTime,
    @Check,
    @IsImported,
    @IsStandard,
    @IsCompulsory,
    @AskOnQuote,
    @AskOnOTP,
    @IsEditPrice,
    @AccessoryId,
    @ModelId

  )
END
