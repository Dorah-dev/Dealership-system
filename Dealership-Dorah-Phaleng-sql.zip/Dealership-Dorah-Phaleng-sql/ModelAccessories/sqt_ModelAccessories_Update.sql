USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_ModelAccessories_Update]
		@Id int,
	 	@Deleted bit = NULL,
		@Active bit = NULL,
    	@BaseCostPrice money = NULL,
    	@BasePrice money = NULL,
		@DateRunIn datetime=NULL,
		@DateRunOut datetime=NULL,
		@Sequence int = NULL,
		@Quantity int = NULL,
    	@FitmentTime decimal(13,2) = NULL,
    	@Check int=NULL,
    	@IsImported bit = NULL,
    	@IsStandard  bit = NULL,
    	@IsCompulsory bit = NULL,
    	@AskOnQuote bit = NULL,
    	@AskOnOTP bit = NULL,
    	@IsEditPrice bit = NULL,
    	@AccessoryId bit = NULL,
    	@ModelId bit = NULL
AS
BEGIN
UPDATE ModelAccessories
 	SET
		[Deleted] = ISNULL(@Deleted, [Deleted]),
		[Active] = ISNULL(@Active, [Active]),
		[DateModified] = GETDATE(),
		[BaseCostPrice] = ISNULL(@BaseCostPrice, [BaseCostPrice]),
		[BasePrice] = ISNULL(@BasePrice, [BasePrice]),
		[DateRunIn] =ISNULL(@DateRunIn, [DateRunIn]),
		[DateRunOut] =ISNULL(@DateRunOut, [DateRunOut]),
		[FitmentTime] = ISNULL(@FitmentTime, [FitmentTime]),
		[Check] = ISNULL(@Check, [Check]),
		[IsImported] =ISNULL(@IsImported, [IsImported]),
		[IsStandard] =ISNULL(@IsStandard, [IsStandard]),
		[IsCompulsory] =ISNULL(@IsCompulsory, [IsCompulsory]),
		[AskOnQuote] = ISNULL(@AskOnQuote, [AskOnQuote]),
		[AskOnOTP] = ISNULL(@AskOnOTP, [AskOnOTP]),
		[IsEditPrice] =ISNULL(@IsEditPrice, [IsEditPrice]),
		[AccessoryId] = ISNULL(@AccessoryId, [AccessoryId]),
		[ModelId] = ISNULL(@ModelId, [ModelId])

	WHERE
		Id = @Id
END
