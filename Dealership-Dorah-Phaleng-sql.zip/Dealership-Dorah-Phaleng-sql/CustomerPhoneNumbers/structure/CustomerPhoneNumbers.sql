USE [DealershipApp]
GO

/****** Object:  Table [dbo].[CustomerPhoneNumbers]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CustomerPhoneNumbers](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[PhoneNumber] [varchar](25) NULL,
	[IntlDialCode] [varchar](5) NULL,
	[IsConfirmed] [bit] NOT NULL,
	[IsDuplicate] [bit] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[PhoneNumberTypeId] [int] NOT NULL,
	[ifkPhoneNumberTypeId] [int] NULL,
	[ifkCustomerId] [int] NULL,
	[ipkCustomerPhoneNumberId] [int] NULL,
 CONSTRAINT [PK_CustomerPhoneNumbers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers] ADD  CONSTRAINT [DF_CustomerPhoneNumbers_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers] ADD  CONSTRAINT [DF_CustomerPhoneNumbers_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers] ADD  CONSTRAINT [DF_CustomerPhoneNumbers_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers] ADD  CONSTRAINT [DF_CustomerPhoneNumbers_IsConfirmed]  DEFAULT ((0)) FOR [IsConfirmed]
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers] ADD  CONSTRAINT [DF_CustomerPhoneNumbers_IsDuplicate]  DEFAULT ((0)) FOR [IsDuplicate]
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers]  WITH CHECK ADD  CONSTRAINT [FK_CustomerPhoneNumbers_Customers] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customers] ([Id])
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers] CHECK CONSTRAINT [FK_CustomerPhoneNumbers_Customers]
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers]  WITH CHECK ADD  CONSTRAINT [FK_CustomerPhoneNumbers_PhoneNumberTypes] FOREIGN KEY([PhoneNumberTypeId])
REFERENCES [dbo].[PhoneNumberTypes] ([Id])
GO

ALTER TABLE [dbo].[CustomerPhoneNumbers] CHECK CONSTRAINT [FK_CustomerPhoneNumbers_PhoneNumberTypes]
GO

