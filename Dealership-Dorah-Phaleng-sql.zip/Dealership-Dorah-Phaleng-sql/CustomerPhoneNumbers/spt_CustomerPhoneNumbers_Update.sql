USE DealershipApp
GO

CREATE PROC [dbo].[spt_CustomerPhoneNumbers_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@PhoneNumber varchar(25) = NULL,
		@IntlDialCode varchar(5) = NULL,
		@IsConfirmed bit = NULL,
		@IsDuplicate bit = NULL,
		@CustomerId int = NULL,
		@PhoneNumberTypeId int = NULL
 AS
 BEGIN
	UPDATE CustomerPhoneNumbers
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		PhoneNumber = ISNULL(@PhoneNumber,PhoneNumber),
		IntlDialCode = ISNULL(@IntlDialCode,IntlDialCode),
		IsConfirmed = ISNULL(@IsConfirmed,IsConfirmed),
		IsDuplicate = ISNULL(@IsDuplicate,IsDuplicate),
		CustomerId = ISNULL(@CustomerId,CustomerId),
		PhoneNumberTypeId = ISNULL(@PhoneNumberTypeId,PhoneNumberTypeId)


	WHERE
		Id = @Id 
END