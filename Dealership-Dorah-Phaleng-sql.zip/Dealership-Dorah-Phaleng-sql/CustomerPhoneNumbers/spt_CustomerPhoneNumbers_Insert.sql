USE DealershipApp
GO

ALTER PROC [dbo].[spt_CustomerPhoneNumbers_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@PhoneNumber varchar(25),
		@IntlDialCode varchar(5),
		@IsConfirmed bit = 0,
		@IsDuplicate bit = 0,
		@CustomerId int,
		@PhoneNumberTypeId int
 AS
 BEGIN
	IF (NOT EXISTS(SELECT Id FROM CustomerPhoneNumbers WHERE CustomerId = @CustomerId and PhoneNumberTypeId = @PhoneNumberTypeId and Deleted = 0))
	BEGIN
		INSERT INTO CustomerPhoneNumbers
		(
			Deleted,
			Active,
			PhoneNumber,
			IntlDialCode,
			IsConfirmed,
			IsDuplicate,
			CustomerId,
			PhoneNumberTypeId
		) OUTPUT INSERTED.Id
		VALUES
		(
			@Deleted,
			@Active,
			@PhoneNumber,
			@IntlDialCode,
			@IsConfirmed,
			@IsDuplicate,
			@CustomerId,
			@PhoneNumberTypeId
		)
	END
END
