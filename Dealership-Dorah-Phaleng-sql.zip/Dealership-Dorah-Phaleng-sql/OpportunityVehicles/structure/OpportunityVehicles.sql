USE [DealershipApp]
GO

/****** Object:  Table [dbo].[OpportunityVehicles]    Script Date: 2021/11/20 8:43:56 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OpportunityVehicles](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[OpportunityId] [int] NULL,
	[ModelId] [int] NULL,
	[MMcode] [varchar](50) NULL,
	[ModelYear] [int] NULL,
	[VehicleStockId] [int] NULL,
	[SalesStepId] [int] NULL,
	[ContactId] [int] NULL,
	[ColourId] [int] NULL,
	[ExtraColourId] [int] NULL,
	[ExtraTrimId] [int] NULL,
	[FMLRentalContactId] [int] NULL,
	[FMLRentalCustomerId] [int] NULL,
	[OpportunityLoyaltyProgramId] [int] NULL,
	[DidNotBuyCategoryId] [int] NULL,
	[DidNotBuyReason] [varchar](512) NULL,
	[MemberLoyaltyNumber] [varchar](30) NULL,
	[FinancePolicyNumber] [varchar](50) NULL,
	[IsCompleted] [bit] NOT NULL,
	[IsUsed] [bit] NOT NULL,
	[IsSighted] [bit] NOT NULL,
	[IsUpdated] [bit] NOT NULL,
	[IsQuoteApproved] [bit] NOT NULL,
	[QuoteNumber] [varchar](32) NULL,
	[OTPNumber] [varchar](64) NULL,
	[FinanceStatus] [varchar](32) NULL,
	[FinanceExternalNumber] [varchar](50) NULL,
	[FinanceDealerCode] [varchar](50) NULL,
	[ExchangeRate] [decimal](15, 2) NULL,
	[CurrentModelPrice] [money] NULL,
	[BaseAmount] [money] NULL,
	[BasePrice] [money] NULL,
	[BaseDiscountPrice] [money] NULL,
	[BaseDiscountAmount] [money] NULL,
	[DiscountPercent] [decimal](15, 2) NOT NULL,
	[ApprovedDiscount] [money] NULL,
	[Vat] [money] NULL,
	[Deposit] [money] NOT NULL,
	[BaseTotalPrice] [money] NOT NULL,
	[TotalAccessories] [money] NULL,
	[PreVATSubTotal] [money] NULL,
	[TotalTradeinOffer] [money] NULL,
	[TotalTradeinSettlement] [money] NULL,
	[TotalDeposit] [money] NULL,
	[TotalVAT] [money] NULL,
	[PostVATSubTotal] [money] NULL,
	[TotalNonVATAccessories] [money] NULL,
	[VehicleGross] [money] NULL,
	[AccessoryGross] [money] NULL,
	[ProfitGross] [money] NULL,
	[EstimatedReconditioning] [money] NULL,
	[DateDue] [datetime] NULL,
	[DateOTPCreated] [datetime] NULL,
	[DateQuoteCreated] [datetime] NULL,
	[DateSentToFinance] [datetime] NULL,
	[DateCompleted] [datetime] NULL,
	[DateDelivery] [datetime] NULL,
	[DateReceivedFromFinance] [datetime] NULL,
	[DateSendtoDMS] [datetime] NULL,
	[DateModifiedByFinance] [datetime] NULL,
	[DateCostSheetCreated] [datetime] NULL,
	[DateTestDrivePrinted] [datetime] NULL,
	[DateDeliveryNotePrinted] [datetime] NULL,
	[DateClientAcceptedQuote] [datetime] NULL,
	[DateClientRejectedQuote] [datetime] NULL,
	[QuoteRevisionCount] [int] NOT NULL,
	[TradeinRevCount] [int] NULL,
	[SARSRevCount] [int] NULL,
	[ipkOpportunityVehicleId] [int] NULL,
 CONSTRAINT [PK_OpportunityVehicles] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_IsCompleted]  DEFAULT ((0)) FOR [IsCompleted]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_IsUsed]  DEFAULT ((0)) FOR [IsUsed]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_IsSighted]  DEFAULT ((0)) FOR [IsSighted]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_IsUpdated]  DEFAULT ((0)) FOR [IsUpdated]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_IsQuoteApproved]  DEFAULT ((1)) FOR [IsQuoteApproved]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_BaseTotalPrice]  DEFAULT ((0)) FOR [BaseTotalPrice]
GO

ALTER TABLE [dbo].[OpportunityVehicles] ADD  CONSTRAINT [DF_OpportunityVehicles_QuoteRevisionCount]  DEFAULT ((0)) FOR [QuoteRevisionCount]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_AccessoiesColour] FOREIGN KEY([ColourId])
REFERENCES [dbo].[Accessories] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_AccessoiesColour]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_AccessoriesExtraColour] FOREIGN KEY([ExtraColourId])
REFERENCES [dbo].[Accessories] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_AccessoriesExtraColour]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_AccessoriesExtraTrim] FOREIGN KEY([ExtraTrimId])
REFERENCES [dbo].[Accessories] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_AccessoriesExtraTrim]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_CustomerContactFMLRental] FOREIGN KEY([FMLRentalContactId])
REFERENCES [dbo].[Customers] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_CustomerContactFMLRental]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_CustomerFMLRental] FOREIGN KEY([FMLRentalCustomerId])
REFERENCES [dbo].[Customers] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_CustomerFMLRental]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_Customers] FOREIGN KEY([ContactId])
REFERENCES [dbo].[Customers] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_Customers]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_DidNotBuyCategories] FOREIGN KEY([DidNotBuyCategoryId])
REFERENCES [dbo].[DidNotBuyCategories] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_DidNotBuyCategories]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_Models] FOREIGN KEY([ModelId])
REFERENCES [dbo].[Models] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_Models]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_Opportunities] FOREIGN KEY([OpportunityId])
REFERENCES [dbo].[Opportunities] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_Opportunities]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_OpportunityLoyaltyPrograms] FOREIGN KEY([OpportunityLoyaltyProgramId])
REFERENCES [dbo].[OpportunityLoyaltyPrograms] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_OpportunityLoyaltyPrograms]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_SalesSteps] FOREIGN KEY([SalesStepId])
REFERENCES [dbo].[SalesSteps] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_SalesSteps]
GO

ALTER TABLE [dbo].[OpportunityVehicles]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityVehicles_VehicleStock] FOREIGN KEY([VehicleStockId])
REFERENCES [dbo].[VehicleStock] ([Id])
GO

ALTER TABLE [dbo].[OpportunityVehicles] CHECK CONSTRAINT [FK_OpportunityVehicles_VehicleStock]
GO
