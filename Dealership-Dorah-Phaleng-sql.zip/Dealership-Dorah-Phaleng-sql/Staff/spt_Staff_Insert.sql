USE [DealershipApp]
GO

ALTER PROC [dbo].[spt_Staff_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@ShortName varchar(50) = NULL,
		@IDNumber varchar(16) = NULL,
		@Surname varchar(100) = NULL,
		@Email varchar(128) = NULL,
		@PhoneNumber varchar(25) = NULL,
		@FirstName varchar(100) = NULL,
		@Region varchar(50) = NULL,
		@Initial varchar(10) = NULL,
		@IsTechnicalAdvisor bit = 0,
		@DateBirthday datetime = NULL,
		@TitleId int = NULL,
		@GenderId int = NULL,
		@UserId int = NULL
 AS
 BEGIN
	INSERT INTO Staff
	(
		Deleted,
		Active,
		ShortName,
		IDNumber,
		Surname,
		Email,
		PhoneNumber,
		FirstName,
		Region,
		Initial,
		IsTechnicalAdvisor,
		DateBirthday,
		TitleId,
		GenderId,
		UserId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@ShortName,
		@IDNumber,
		@Surname,
		@Email,
		@PhoneNumber,
		@FirstName,
		@Region,
		@Initial,
		@IsTechnicalAdvisor,
		@DateBirthday,
		@TitleId,
		@GenderId,
		@UserId
	)
END
