USE DealershipApp
GO

CREATE PROC [dbo].[spt_Staff_Update]
		@Id int,
		@Deleted bit = 0,
		@Active bit = 1,
		@ShortName varchar(50) = NULL,
		@IDNumber varchar(16) = NULL,
		@Surname varchar(100) = NULL,
		@Email varchar(128) = NULL,
		@PhoneNumber varchar(25) = NULL,
		@FirstName varchar(100) = NULL,
		@Region varchar(50) = NULL,
		@Initial varchar(10) = NULL,
		@IsTechnicalAdvisor bit = 0,
		@DateBirthday datetime = NULL,
		@TitleId int = NULL,
		@GenderId int = NULL,
		@UserId int = NULL
 AS
 BEGIN
	UPDATE Staff
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		ShortName = ISNULL(@ShortName,ShortName),
		IDNumber = ISNULL(@IDNumber,IDNumber),
		Surname = ISNULL(@Surname,Surname),
		Email = ISNULL(@Email,Email),
		PhoneNumber = ISNULL(@PhoneNumber,PhoneNumber),
		FirstName = ISNULL(@FirstName,FirstName),
		Region = ISNULL(@Region,Region),
		Initial = ISNULL(@Initial,Initial),
		IsTechnicalAdvisor = ISNULL(@IsTechnicalAdvisor,IsTechnicalAdvisor),
		DateBirthday = ISNULL(@DateBirthday,DateBirthday),
		TitleId = ISNULL(@TitleId,TitleId),
		GenderId = ISNULL(@GenderId,GenderId),
		UserId = ISNULL(@UserId,UserId)
	WHERE
		Id = @Id
END
