USE [DealershipApp]
GO

ALTER PROC [dbo].[spt_UserFeatures_Update]
		@Id int,
		@Deleted bit = 0,
		@Active bit = 1,
		@UserId int = NULL,
		@FeatureId int = NULL
 AS
 BEGIN
	UPDATE UserFeatures
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		UserId = ISNULL(@UserId,UserId),
		FeatureId = ISNULL(@FeatureId,FeatureId)
	WHERE
		Id = @Id
END
