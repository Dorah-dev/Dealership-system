USE [DealershipApp]
GO

/****** Object:  Table [dbo].[UserFeatures]    Script Date: 2021/11/19 1:40:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserFeatures](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[UserId] [int] NOT NULL,
	[FeatureId] [int] NOT NULL,
 CONSTRAINT [PK_UserFeatures] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[UserFeatures] ADD  CONSTRAINT [DF_UserFeatures_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[UserFeatures] ADD  CONSTRAINT [DF_UserFeatures_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[UserFeatures] ADD  CONSTRAINT [DF_UserFeatures_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[UserFeatures]  WITH CHECK ADD  CONSTRAINT [FK_UserFeatures_Features] FOREIGN KEY([FeatureId])
REFERENCES [dbo].[Features] ([Id])
GO

ALTER TABLE [dbo].[UserFeatures] CHECK CONSTRAINT [FK_UserFeatures_Features]
GO

ALTER TABLE [dbo].[UserFeatures]  WITH CHECK ADD  CONSTRAINT [FK_UserFeatures_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO

ALTER TABLE [dbo].[UserFeatures] CHECK CONSTRAINT [FK_UserFeatures_Users]
GO


