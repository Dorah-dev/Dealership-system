USE [DealershipApp]
GO

ALTER PROC [dbo].[spt_UserFeatures_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@UserId int = NULL,
		@FeatureId int = NULL
 AS
 BEGIN
	INSERT INTO UserFeatures
	(
		Deleted,
		Active,
		UserId,
		FeatureId
	) OUTPUT INSERTED.Id 
	VALUES
	(
		@Deleted,
		@Active,
		@UserId,
		@FeatureId
	)
END
