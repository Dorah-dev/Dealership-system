USE DealershipApp
GO

ALTER PROC [dbo].[spt_DealershipModules_Update]
		@Deleted bit = NULL,
		@Active bit = NULL,
		@DealershipId int,
		@ModuleId int
 AS
 BEGIN
	UPDATE DealershipModules
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active)
	WHERE
		DealershipId = @DealershipId and ModuleId = @ModuleId --cannot have more than one entry with same role and feature id (compositly unique)
END