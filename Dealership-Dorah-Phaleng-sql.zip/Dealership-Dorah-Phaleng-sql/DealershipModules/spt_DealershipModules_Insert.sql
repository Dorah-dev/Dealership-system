USE DealershipApp
GO

ALTER PROC [dbo].[spt_DealershipModules_Insert]
		@DealershipId int,
		@ModuleId int
 AS
 BEGIN
	IF (NOT EXISTS(SELECT Id FROM DealershipModules WHERE DealershipId = @DealershipId and ModuleId = @ModuleId and Deleted = 0))
	BEGIN
		INSERT INTO DealershipModules
		(
			DealershipId,
			ModuleId
		) OUTPUT INSERTED.Id
		VALUES
		(
			@DealershipId,
			@ModuleId
		)
	END
END
