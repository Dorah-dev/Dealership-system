USE DealershipApp
GO

CREATE PROC [dbo].[spt_UserTypeLinks_Update]
		@Id int,
		@Deleted bit = 0,
		@Active bit = 1,
		@UserId int = NULL,
		@UserTypeId int = NULL
 AS
 BEGIN
	UPDATE UserTypeLinks
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		UserId = ISNULL(@UserId,UserId),
		UserTypeId = ISNULL(@UserTypeId,UserTypeId)
	WHERE
		Id = @Id
END