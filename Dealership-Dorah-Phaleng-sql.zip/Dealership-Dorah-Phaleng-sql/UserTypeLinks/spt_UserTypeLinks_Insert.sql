USE DealershipApp
GO

ALTER PROC [dbo].[spt_UserTypeLinks_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@UserId int = NULL,
		@UserTypeId int = NULL
 AS
 BEGIN
	INSERT INTO UserTypeLinks
	(
		Deleted,
		Active,
		UserId,
		UserTypeId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@UserId,
		@UserTypeId
	)
END
