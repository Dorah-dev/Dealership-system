USE [TEST]
GO


CREATE PROC [dbo].[spt_RegisterUsers_Insert]
                  @Deleted bit = 0,
                  @Active bit = 1,
                  @FirstName varchar(50) = NULL
                  @LastName varchar(50) = NULL
                  @Email Address varchar(50) = NULL
                  @Password varchar(50) = NULL
                  @DateStamp datetime = NULL,
                  
AS
BEGIN
	INSERT INTO RegisterUsers
	(
		[Deleted],
		[Active],
    [FirstName],
    [LastName],
    [Password],
    [Email Address],
    [DateStamp]
    
	)
  OUTPUT INSERTED.Id
	VALUES
	(
    @Deleted,
    @Active,
    @FirstName,
    @LastName ,
    @Password,
    @Email Active,
    @DateStamp,
    
	)
END
