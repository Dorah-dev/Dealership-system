USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_Vehicles_Update]
		@Id int,
	    @Deleted bit = NULL,
		@Active bit = NULL,
		@ModelYear int = NULL,
		@ChassisNumber varchar(32) = NULL,
		@EngineNumber varchar(32) = NULL,
		@Vin varchar(32) = NULL,
		@Gear int = NULL,
		@StockNumber varchar(100) = NULL,
		@IsMasterVehicle bit = NULL,
		@ODOMeterReading int = NULL,
		@DateOfFirstRegistration datetime = NULL,
		@DateConstruction datetime = NULL,
		@DateNaamsa datetime = NULL,
		@WMI varchar(3) = NULL,
		@VDSCode varchar(6) = NULL,
		@DateRetail datetime = NULL,
		@DateBuild datetime = NULL,
		@NatisNumber varchar(10) = NULL,
		@DistributionChannel varchar(5) = NULL,
		@ColourId int = NULL,
		@CustomerId int = NULL,
		@ModelId int = NULL,
		@MMCodeId int = NULL,
		@SellingDealerId int = NULL,
		@TradeinCustomerId int = NULL,
		@TransmissionId int = NULL,
		@TrimId int = NULL,
		@RegistrationNumber varchar(20) = NULL
AS
BEGIN
UPDATE Vehicles
 	SET
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DateModified = GETDATE(),
		ModelYear = ISNULL(@ModelYear,ModelYear),
		ChassisNumber = ISNULL(@ChassisNumber,ChassisNumber),
		EngineNumber = ISNULL(@EngineNumber,EngineNumber),
		Vin = ISNULL(@Vin,Vin),
		Gear = ISNULL(@Gear,Gear),
		StockNumber = ISNULL(@StockNumber,StockNumber),
		IsMasterVehicle = ISNULL(@IsMasterVehicle,IsMasterVehicle),
		ODOMeterReading = ISNULL(@ODOMeterReading,ODOMeterReading),
		DateOfFirstRegistration = ISNULL(@DateOfFirstRegistration,DateOfFirstRegistration),
		DateConstruction = ISNULL(@DateConstruction,DateConstruction),
		DateNaamsa = ISNULL(@DateNaamsa,DateNaamsa),
		WMI = ISNULL(@WMI,WMI),
		VDSCode = ISNULL(@VDSCode,VDSCode),
		DateRetail = ISNULL(@DateRetail,DateRetail),
		DateBuild = ISNULL(@DateBuild,DateBuild),
		NatisNumber = ISNULL(@NatisNumber,NatisNumber),
		DistributionChannel = ISNULL(@DistributionChannel,DistributionChannel),
		ColourId = ISNULL(@ColourId,ColourId),
		CustomerId = @CustomerId,
		ModelId = ISNULL(@ModelId,ModelId),
		MMCodeId = ISNULL(@MMCodeId,MMCodeId),
		SellingDealerId = ISNULL(@SellingDealerId,SellingDealerId),
		TradeinCustomerId = ISNULL(@TradeinCustomerId,TradeinCustomerId),
		TransmissionId = ISNULL(@TransmissionId,TransmissionId),
		TrimId = ISNULL(@TrimId,TrimId),
		RegistrationNumber = ISNULL(@RegistrationNumber,RegistrationNumber)
	WHERE
		Id = @Id
END
GO
