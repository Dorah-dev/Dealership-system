USE Toyota
GO

ALTER PROC [dbo].[spt_ComponentSettings_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(32) = NULL,
		@Description varchar(512) = NULL,
		@Code varchar(10) = NULL,
		@ComponentId int = NULL
 AS
 BEGIN
	UPDATE ComponentSettings
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name,Name),
		Description = ISNULL(@Description,Description),
		Code = ISNULL(@Code,Code),
		ComponentId = ISNULL(@ComponentId,ComponentId)
	WHERE
		Id = @Id
END
