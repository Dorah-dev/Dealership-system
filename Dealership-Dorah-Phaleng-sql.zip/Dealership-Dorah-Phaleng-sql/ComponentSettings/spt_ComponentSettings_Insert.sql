USE DealershipApp
GO

ALTER PROC [dbo].[spt_ComponentSettings_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(32),
		@Description varchar(512) = NULL,
		@Code varchar(10),
		@ComponentId int = NULL
 AS
 BEGIN
	INSERT INTO ComponentSettings
	(
		Deleted,
		Active,
		Name,
		Description,
		Code,
		ComponentId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@Description,
		@Code,
		@ComponentId
	)
END
