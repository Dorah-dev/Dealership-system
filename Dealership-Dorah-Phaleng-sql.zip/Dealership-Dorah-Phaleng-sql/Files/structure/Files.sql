USE [DealershipApp]
GO

/****** Object:  Table [dbo].[Files]    Script Date: 11/20/2021 2:16:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Files](
	[Id] [int] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[Name] [varchar](255) NULL,
	[Description] [varchar](512) NULL,
	[FilePath] [varchar](256) NULL,
	[FileName] [varchar](256) NULL,
	[FileSize] [decimal](15, 2) NULL,
	[MIMEType] [varchar](128) NULL,
	[FileVersion] [int] NULL,
	[FileTypeId] [int] NOT NULL,
	[ipkCareAttachmentsId] [int] NULL,
	[ipkWholesaleDocId] [int] NULL,
	[ipkUsedVehicleStockImageId] [int] NULL,
	[ipkOppAttachmentId] [int] NULL,
	[ipkDocumentPartId] [int] NULL,
 CONSTRAINT [PK_Files] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Files] ADD  CONSTRAINT [DF_Files_Id]  DEFAULT (NEXT VALUE FOR [dbo].[FilesSequence]) FOR [Id]
GO

ALTER TABLE [dbo].[Files] ADD  CONSTRAINT [DF_Files_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[Files] ADD  CONSTRAINT [DF_Files_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[Files] ADD  CONSTRAINT [DF_Files_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[Files]  WITH CHECK ADD  CONSTRAINT [FK_Files_FileTypes] FOREIGN KEY([FileTypeId])
REFERENCES [dbo].[FileTypes] ([Id])
GO

ALTER TABLE [dbo].[Files] CHECK CONSTRAINT [FK_Files_FileTypes]
GO
