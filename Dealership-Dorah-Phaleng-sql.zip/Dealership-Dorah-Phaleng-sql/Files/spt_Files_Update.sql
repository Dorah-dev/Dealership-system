USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_Files_Update]
		@Id int,
	    @Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(255) = NULL,
		@Description varchar(512) = NULL,
		@FilePath varchar(256) = NULL,
		@FileName varchar(256) = NULL,
		@FileSize decimal(15,2) = NULL,
		@MIMEType varchar(128) = NULL,
		@FileVersion int = NULL,
		@FileTypeId int = NULL
AS
BEGIN
UPDATE Files
 	SET
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		DateModified = GETDATE(),
		Name = ISNULL(@Name,Name),
		Description = ISNULL(@Description,Description),
		FilePath = ISNULL(@FilePath,FilePath),
		FileName = ISNULL(@FileName,FileName),
		FileSize = ISNULL(@FileSize,FileSize),
		MIMEType = ISNULL(@MIMEType,MIMEType),
		FileVersion = ISNULL(@FileVersion,FileVersion),
		FileTypeId = ISNULL(@FileTypeId,FileTypeId)
	WHERE
		Id = @Id
END
GO
