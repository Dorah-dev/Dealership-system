USE [DealershipApp]
GO


CREATE  PROC [dbo].[spt_Files_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(255) = NULL,
		@Description varchar(512) = NULL,
		@FilePath varchar(256) = NULL,
		@FileName varchar(256) = NULL,
		@FileSize decimal(15,2) = NULL,
		@MIMEType varchar(128) = NULL,
		@FileVersion int = NULL,
		@FileTypeId int = NULL
AS
BEGIN
	INSERT INTO Files
	(
		Deleted,
		Active,
		Name,
		Description,
		FilePath,
		FileName,
		FileSize,
		MIMEType,
		FileVersion,
		FileTypeId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@Description,
		@FilePath,
		@FileName,
		@FileSize,
		@MIMEType,
		@FileVersion,
		@FileTypeId
	)
END
