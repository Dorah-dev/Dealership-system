USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_ServiceBookings_Update]
    @Id int,
    @Deleted bit = NULL,
	@Active bit = NULL,
	@Name varchar(255) = NULL,
	@Code varchar(32) = NULL,
	@Quantity decimal(15, 2) = NULL,
	@IsWarrantyClaim bit = NULL,
	@IsServicePlan bit = NULL,
	@IsMaintenancePlan bit = NULL,
	@IsPartOnOrder bit = NULL,
	@IsClientBillable bit = NULL,
	@IsExtraPart bit = NULL,
	@TaskIndicator varchar(1) = NULL,
	@Unit varchar(25) = NULL,
	@SequenceItem int = NULL,
	@DMSLineNumber int = NULL,
	@ConvertedUnitPrice money = NULL,
	@DiscountPercentage decimal(15, 2) = NULL,
	@ConvertedDiscountAmount money = NULL,
	@BaseUnitPrice money = NULL,
	@BaseDiscountAmount money = NULL,
	@ServiceBookingTaskId int = NULL,
	@ServiceTaskPartSubstituteId int = NULL
AS
BEGIN
    UPDATE [dbo].[ServiceBookingTaskParts]
    SET
        DateModified = GETDATE(),
        Deleted = ISNULL(@Deleted,Deleted),
        Active = ISNULL(@Active,Active),
        [Name] = ISNULL(@Name,[Name]),
        Code = ISNULL(@Code,Code),
        Quantity = ISNULL(@Quantity,Quantity),
        IsWarrantyClaim = ISNULL(@IsWarrantyClaim,IsWarrantyClaim),
        IsServicePlan = ISNULL(@IsServicePlan,IsServicePlan),
        IsMaintenancePlan = ISNULL(@IsMaintenancePlan,IsMaintenancePlan),
        IsPartOnOrder = ISNULL(@IsPartOnOrder,IsPartOnOrder),
        IsClientBillable = ISNULL(@IsClientBillable,IsClientBillable),
        IsExtraPart = ISNULL(@IsExtraPart,IsExtraPart),
        TaskIndicator = ISNULL(@TaskIndicator,TaskIndicator),
        Unit = ISNULL(@Unit,Unit),
        SequenceItem = ISNULL(@SequenceItem,SequenceItem),
        DMSLineNumber = ISNULL(@DMSLineNumber,DMSLineNumber),
        ConvertedUnitPrice = ISNULL(@ConvertedUnitPrice,ConvertedUnitPrice),
        DiscountPercentage = ISNULL(@DiscountPercentage,DiscountPercentage),
        ConvertedDiscountAmount = ISNULL(@ConvertedDiscountAmount,ConvertedDiscountAmount),
        BaseUnitPrice = ISNULL(@BaseUnitPrice,BaseUnitPrice),
        BaseDiscountAmount = ISNULL(@BaseDiscountAmount,BaseDiscountAmount),
        ServiceBookingTaskId = ISNULL(@ServiceBookingTaskId,ServiceBookingTaskId),
        ServiceTaskPartSubstituteId = ISNULL(@ServiceTaskPartSubstituteId,ServiceTaskPartSubstituteId)
    WHERE
        Id = @Id

END

GO
