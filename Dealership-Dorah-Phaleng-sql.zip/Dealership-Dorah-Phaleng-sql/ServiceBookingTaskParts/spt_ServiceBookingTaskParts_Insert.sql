USE [DealershipApp]
GO

CREATE PROC [dbo].[spt_ServiceBookingTaskParts_Insert]
	@Deleted bit = 0,
	@Active bit = 1,
	@Name varchar(255) = NULL,
	@Code varchar(32) = NULL,
	@Quantity decimal(15, 2) = NULL,
	@IsWarrantyClaim bit = 0,
	@IsServicePlan bit = 0,
	@IsMaintenancePlan bit = 0,
	@IsPartOnOrder bit = 0,
	@IsClientBillable bit = 0,
	@IsExtraPart bit = 0,
	@TaskIndicator varchar(1) = NULL,
	@Unit varchar(25) = NULL,
	@SequenceItem int = NULL,
	@DMSLineNumber int = NULL,
	@ConvertedUnitPrice money = NULL,
	@DiscountPercentage decimal(15, 2) = NULL,
	@ConvertedDiscountAmount money = NULL,
	@BaseUnitPrice money = NULL,
	@BaseDiscountAmount money = NULL,
	@ServiceBookingTaskId int = NULL,
	@ServiceTaskPartSubstituteId int = NULL
AS
BEGIN

	INSERT INTO [dbo].[ServiceBookingTaskParts]
    (
        Deleted,
        Active,
        [Name],
        Code,
        Quantity,
        IsWarrantyClaim,
        IsServicePlan,
        IsMaintenancePlan,
        IsPartOnOrder,
        IsClientBillable,
        IsExtraPart,
        TaskIndicator,
        Unit,
        SequenceItem,
        DMSLineNumber,
        ConvertedUnitPrice,
        DiscountPercentage,
        ConvertedDiscountAmount,
        BaseUnitPrice,
        BaseDiscountAmount,
        ServiceBookingTaskId,
        ServiceTaskPartSubstituteId
    )  OUTPUT INSERTED.Id
    VALUES
    (
        @Deleted,
        @Active,
        @Name,
        @Code,
        @Quantity,
        @IsWarrantyClaim,
        @IsServicePlan,
        @IsMaintenancePlan,
        @IsPartOnOrder,
        @IsClientBillable,
        @IsExtraPart,
        @TaskIndicator,
        @Unit,
        @SequenceItem,
        @DMSLineNumber,
        @ConvertedUnitPrice,
        @DiscountPercentage,
        @ConvertedDiscountAmount,
        @BaseUnitPrice,
        @BaseDiscountAmount,
        @ServiceBookingTaskId,
        @ServiceTaskPartSubstituteId
	)
END

GO
