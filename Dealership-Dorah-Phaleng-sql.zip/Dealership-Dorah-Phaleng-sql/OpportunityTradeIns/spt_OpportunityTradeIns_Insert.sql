USE DealershipApp
GO

ALTER PROC [dbo].[spt_OpportunityTradeIns_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@OpportunityVehicleId int = NULL,
		@VehicleId int = NULL,
		@FinanceCompanyId int = NULL,
		@TradeInValue money = NULL,
		@Settlement money = NULL,
		@ExpectedAmount money = NULL,
		@InvoiceNumber varchar(50) = NULL,
		@StockNumber varchar(50) = NULL,
		@OverAllowance money = NULL,
		@FinanceCompanyOther varchar(128) = NULL,
		@FinanceBranch varchar(100) = NULL,
		@FinanceAccountNumber varchar(50) = NULL,
		@FinanceContactName varchar(100) = NULL,
		@FinancePhoneNumber varchar(50) = NULL,
		@DateExpire datetime = NULL,
		@ValuationNumber varchar(50) = NULL,
		@DateTradeInDocumentPrinted datetime = NULL
 AS
 BEGIN
	INSERT INTO OpportunityTradeIns
	(
		Deleted,
		Active,
		OpportunityVehicleId,
		VehicleId,
		FinanceCompanyId,
		TradeInValue,
		Settlement,
		ExpectedAmount,
		InvoiceNumber,
		StockNumber,
		OverAllowance,
		FinanceCompanyOther,
		FinanceBranch,
		FinanceAccountNumber,
		FinanceContactName,
		FinancePhoneNumber,
		DateExpire,
		ValuationNumber,
		DateTradeInDocumentPrinted

	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@OpportunityVehicleId,
		@VehicleId,
		@FinanceCompanyId,
		@TradeInValue,
		@Settlement,
		@ExpectedAmount,
		@InvoiceNumber,
		@StockNumber,
		@OverAllowance,
		@FinanceCompanyOther,
		@FinanceBranch,
		@FinanceAccountNumber,
		@FinanceContactName,
		@FinancePhoneNumber,
		@DateExpire,
		@ValuationNumber,
		@DateTradeInDocumentPrinted
	)
END
