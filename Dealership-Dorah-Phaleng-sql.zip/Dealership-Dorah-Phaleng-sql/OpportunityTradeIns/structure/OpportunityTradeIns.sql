USE [DealershipApp]
GO

/****** Object:  Table [dbo].[OpportunityTradeIns]    Script Date: 2021/11/20 8:43:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OpportunityTradeIns](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[OpportunityVehicleId] [int] NULL,
	[VehicleId] [int] NULL,
	[FinanceCompanyId] [int] NULL,
	[TradeInValue] [money] NULL,
	[Settlement] [money] NULL,
	[ExpectedAmount] [money] NULL,
	[InvoiceNumber] [varchar](50) NULL,
	[StockNumber] [varchar](50) NULL,
	[OverAllowance] [money] NULL,
	[FinanceCompanyOther] [varchar](128) NULL,
	[FinanceBranch] [varchar](100) NULL,
	[FinanceAccountNumber] [varchar](50) NULL,
	[FinanceContactName] [varchar](100) NULL,
	[FinancePhoneNumber] [varchar](50) NULL,
	[DateExpire] [datetime] NULL,
	[ValuationNumber] [varchar](50) NULL,
	[DateTradeInDocumentPrinted] [datetime] NULL,
	[ipkOpportunityTradeInId] [int] NULL,
 CONSTRAINT [PK_OpportunityTradeIns] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[OpportunityTradeIns] ADD  CONSTRAINT [DF_OpportunityTradeIns_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[OpportunityTradeIns] ADD  CONSTRAINT [DF_OpportunityTradeIns_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[OpportunityTradeIns] ADD  CONSTRAINT [DF_OpportunityTradeIns_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[OpportunityTradeIns]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityTradeIns_FinanceCompanies] FOREIGN KEY([FinanceCompanyId])
REFERENCES [dbo].[FinanceCompanies] ([Id])
GO

ALTER TABLE [dbo].[OpportunityTradeIns] CHECK CONSTRAINT [FK_OpportunityTradeIns_FinanceCompanies]
GO

ALTER TABLE [dbo].[OpportunityTradeIns]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityTradeIns_OpportunityVehicles] FOREIGN KEY([OpportunityVehicleId])
REFERENCES [dbo].[OpportunityVehicles] ([Id])
GO

ALTER TABLE [dbo].[OpportunityTradeIns] CHECK CONSTRAINT [FK_OpportunityTradeIns_OpportunityVehicles]
GO

ALTER TABLE [dbo].[OpportunityTradeIns]  WITH CHECK ADD  CONSTRAINT [FK_OpportunityTradeIns_Vehicles] FOREIGN KEY([VehicleId])
REFERENCES [dbo].[Vehicles] ([Id])
GO

ALTER TABLE [dbo].[OpportunityTradeIns] CHECK CONSTRAINT [FK_OpportunityTradeIns_Vehicles]
GO
