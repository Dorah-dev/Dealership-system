USE DealershipApp
GO

ALTER PROC [dbo].[spt_OpportunityTradeIns_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@OpportunityVehicleId int = NULL,
		@VehicleId int = NULL,
		@FinanceCompanyId int = NULL,
		@TradeInValue money = NULL,
		@Settlement money = NULL,
		@ExpectedAmount money = NULL,
		@InvoiceNumber varchar(50) = NULL,
		@StockNumber varchar(50) = NULL,
		@OverAllowance money = NULL,
		@FinanceCompanyOther varchar(128) = NULL,
		@FinanceBranch varchar(100) = NULL,
		@FinanceAccountNumber varchar(50) = NULL,
		@FinanceContactName varchar(100) = NULL,
		@FinancePhoneNumber varchar(50) = NULL,
		@DateExpire datetime = NULL,
		@ValuationNumber varchar(50) = NULL,
		@DateTradeInDocumentPrinted datetime = NULL
 AS
 BEGIN
	UPDATE OpportunityTradeIns
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		OpportunityVehicleId = ISNULL(@OpportunityVehicleId,OpportunityVehicleId),
		VehicleId = ISNULL(@VehicleId,VehicleId),
		FinanceCompanyId = ISNULL(@FinanceCompanyId,FinanceCompanyId),
		TradeInValue = ISNULL(@TradeInValue,TradeInValue),
		Settlement = ISNULL(@Settlement,Settlement),
		ExpectedAmount = ISNULL(@ExpectedAmount,ExpectedAmount),
		InvoiceNumber = ISNULL(@InvoiceNumber,InvoiceNumber),
		StockNumber = ISNULL(@StockNumber,StockNumber),
		OverAllowance = ISNULL(@OverAllowance,OverAllowance),
		FinanceCompanyOther = ISNULL(@FinanceCompanyOther,FinanceCompanyOther),
		FinanceBranch = ISNULL(@FinanceBranch,FinanceBranch),
		FinanceAccountNumber = ISNULL(@FinanceAccountNumber,FinanceAccountNumber),
		FinanceContactName = ISNULL(@FinanceContactName,FinanceContactName),
		FinancePhoneNumber = ISNULL(@FinancePhoneNumber,FinancePhoneNumber),
		DateExpire = ISNULL(@DateExpire,DateExpire),
		ValuationNumber = ISNULL(@ValuationNumber,ValuationNumber),
		DateTradeInDocumentPrinted = ISNULL(@DateTradeInDocumentPrinted,DateTradeInDocumentPrinted)
	WHERE
		Id = @Id
END
