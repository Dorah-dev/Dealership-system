USE DealershipApp
GO

ALTER PROC [dbo].[spt_DealershipComponents_Update]
		@Deleted bit = NULL,
		@Active bit = NULL,
		@DealershipId int,
		@ComponentId int
 AS
 BEGIN
	UPDATE DealershipComponents
 	SET
 		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active)
	WHERE
		DealershipId = @DealershipId and ComponentId = @ComponentId --cannot have more than one entry with same role and feature id (compositly unique)
END