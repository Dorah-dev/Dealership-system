USE [DealershipApp]
GO

/****** Object:  Table [dbo].[DealershipComponents]    Script Date: 2021/11/10 7:22:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DealershipComponents](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[DateModified] [datetime] NULL,
	[Deleted] [bit] NOT NULL,
	[Active] [bit] NOT NULL,
	[DealershipId] [int] NOT NULL,
	[ComponentId] [int] NOT NULL,
 CONSTRAINT [PK_DealershipComponents] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[DealershipComponents] ADD  CONSTRAINT [DF_DealershipComponents_DateCreated]  DEFAULT (getdate()) FOR [DateCreated]
GO

ALTER TABLE [dbo].[DealershipComponents] ADD  CONSTRAINT [DF_DealershipComponents_Deleted]  DEFAULT ((0)) FOR [Deleted]
GO

ALTER TABLE [dbo].[DealershipComponents] ADD  CONSTRAINT [DF_DealershipComponents_Active]  DEFAULT ((1)) FOR [Active]
GO

ALTER TABLE [dbo].[DealershipComponents]  WITH CHECK ADD  CONSTRAINT [FK_DealershipComponents_Dealerships] FOREIGN KEY([DealershipId])
REFERENCES [dbo].[Dealerships] ([Id])
GO

ALTER TABLE [dbo].[DealershipComponents] CHECK CONSTRAINT [FK_DealershipComponents_Dealerships]
GO

ALTER TABLE [dbo].[DealershipComponents]  WITH CHECK ADD  CONSTRAINT [FK_DealershipComponents_Components] FOREIGN KEY([ComponentId])
REFERENCES [dbo].[Components] ([Id])
GO

ALTER TABLE [dbo].[DealershipComponents] CHECK CONSTRAINT [FK_DealershipComponents_Components]
GO


