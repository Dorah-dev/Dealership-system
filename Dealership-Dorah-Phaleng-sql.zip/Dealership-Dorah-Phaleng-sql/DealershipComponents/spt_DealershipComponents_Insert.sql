USE DealershipApp
GO

ALTER PROC [dbo].[spt_DealershipComponents_Insert]
		@DealershipId int,
		@ComponentId int
 AS
 BEGIN
	IF (NOT EXISTS(SELECT Id FROM DealershipComponents WHERE DealershipId = @DealershipId and ComponentId = @ComponentId and Deleted = 0))
	BEGIN
		INSERT INTO DealershipComponents
		(
			DealershipId,
			ComponentId
		) OUTPUT INSERTED.Id
		VALUES
		(
			@DealershipId,
			@ComponentId
		)
	END
END
