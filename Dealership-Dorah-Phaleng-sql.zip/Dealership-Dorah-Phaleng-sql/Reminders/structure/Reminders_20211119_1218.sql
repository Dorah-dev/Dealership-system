ALTER TABLE [dbo].[Reminders]
ADD UserId [int] NULL
GO
ALTER TABLE [dbo].[Reminders]  WITH CHECK ADD  CONSTRAINT [FK_Reminders_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO
