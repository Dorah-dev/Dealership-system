USE DealershipApp
GO

ALTER PROC [dbo].[spt_Reminders_Insert]
		@Deleted bit = 0,
		@Active bit = 1,
		@Name varchar(32),
		@Description varchar(512) = NULL,
		@DateReminder datetime,
		@ReminderTypeId int,
		@UserId int
 AS
 BEGIN
	INSERT INTO Reminders
	(
		Deleted,
		Active,
		Name,
		Description,
		DateReminder,
		ReminderTypeId,
		UserId
	) OUTPUT INSERTED.Id
	VALUES
	(
		@Deleted,
		@Active,
		@Name,
		@Description,
		@DateReminder,
		@ReminderTypeId,
		@UserId
	)
END
