USE DealershipApp
GO

ALTER PROC [dbo].[spt_Reminders_Update]
		@Id int,
		@Deleted bit = NULL,
		@Active bit = NULL,
		@Name varchar(32) = NULL,
		@Description varchar(512) = NULL,
		@DateReminder datetime = NULL,
		@ReminderTypeId int = NULL,
		@UserId int = NULL
 AS
 BEGIN
	UPDATE Reminders
 	SET
		DateModified = GETDATE(),
		Deleted = ISNULL(@Deleted,Deleted),
		Active = ISNULL(@Active,Active),
		Name = ISNULL(@Name,Name),
		Description = ISNULL(@Description,Description),
		DateReminder = ISNULL(@DateReminder,DateReminder),
		ReminderTypeId = ISNULL(@ReminderTypeId,ReminderTypeId),
		UserId = ISNULL(@UserId,UserId)
	WHERE
		Id = @Id
END
